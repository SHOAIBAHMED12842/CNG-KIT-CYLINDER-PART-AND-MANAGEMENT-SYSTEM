﻿CREATE TABLE [dbo].[Services] (
    [Service_ID]   INT          NOT NULL,
    [Name]         VARCHAR (20) NOT NULL,
    [Amount]       INT          NOT NULL,
    [Item_ID]      INT           NULL,
    CONSTRAINT [PK_Services] PRIMARY KEY CLUSTERED ([Service_ID] ASC),
);


