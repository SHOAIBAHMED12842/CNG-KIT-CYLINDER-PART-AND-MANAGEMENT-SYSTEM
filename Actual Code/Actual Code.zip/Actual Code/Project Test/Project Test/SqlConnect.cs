﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Project_Test
{
    class SqlConnect
    {
        public static string cs = @"Data Source=DESKTOP-MPKH00B;Initial Catalog=CNG_Kits_Cylinders_Parts;Integrated Security=True";
        public static void Save(string quy)
        {
            using (SqlConnection con = new SqlConnection(cs))//delete from tblname where colname ='"++"' update tblname set colname='',colname2='' where colname= ''
            {
                con.Open();
                SqlCommand comd = new SqlCommand(quy, con);
                comd.ExecuteNonQuery();
            }
        }
        public static DataTable fetch(string quy)//select * from tblname where colname = ''
        {
            SqlDataAdapter sd = new SqlDataAdapter(quy,cs);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            return dt;//textbox.text=dt.Rows[0]["customerid"].tostring();//
        }
       
    }
}
