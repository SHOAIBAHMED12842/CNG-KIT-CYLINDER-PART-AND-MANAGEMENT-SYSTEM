﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test
{

    public partial class Item : Form
    {
        public Item()
        {
            InitializeComponent();
        }
        private void Item_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cNG_Kits_Cylinders_PartsDataSet8.Item_Category' table. You can move, or remove it, as needed.
            this.item_CategoryTableAdapter5.Fill(this.cNG_Kits_Cylinders_PartsDataSet8.Item_Category);
            // TODO: This line of code loads data into the 'cNG_Kits_Cylinders_PartsDataSet7.Item_Category' table. You can move, or remove it, as needed.
            this.item_CategoryTableAdapter4.Fill(this.cNG_Kits_Cylinders_PartsDataSet7.Item_Category);
            // TODO: This line of code loads data into the 'cNG_Kits_Cylinders_PartsDataSet6.Item_Category' table. You can move, or remove it, as needed.
            this.item_CategoryTableAdapter3.Fill(this.cNG_Kits_Cylinders_PartsDataSet6.Item_Category);
            // TODO: This line of code loads data into the 'cNG_Kits_Cylinders_PartsDataSet4.Item' table. You can move, or remove it, as needed.
            this.itemTableAdapter.Fill(this.cNG_Kits_Cylinders_PartsDataSet4.Item);
            // TODO: This line of code loads data into the 'cNG_Kits_Cylinders_PartsDataSet3.Item_Category' table. You can move, or remove it, as needed.
            this.item_CategoryTableAdapter1.Fill(this.cNG_Kits_Cylinders_PartsDataSet3.Item_Category);

            panelitem.Show();
            panelitem.BringToFront();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonItemcateg_Click(object sender, EventArgs e)
        {
            panelitemcategory.Show();
            panelitemcategory.BringToFront();
        }

        private void button8Itemreg_Click(object sender, EventArgs e)
        {
            panelitem.Show();
            panelitem.BringToFront();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
            this.Hide();
        }
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text == "" || maskedTextBoxrate.Text == "" || comboBoxitcat.Text == "" || maskedTextBoxquantity.Text == "" || textBoxdes.Text == "")
            {
                MessageBox.Show("Al Feilds are necessary.");
            }
            else
            {
                string loc = "";
                try
                {
                    loc = Path.Combine(Application.StartupPath + @"\Images", Path.GetFileName(textBoxpath.Text));
                    File.Copy(Path.Combine(textBoxpath.Text), loc, true);
                }
                catch (Exception)
                {
                    throw;

                }
                Item_Class i = new Item_Class();
                DataTable d = i.Item_Add(textBoxName.Text, int.Parse(maskedTextBoxrate.Text), comboBoxitcat.Text, int.Parse(maskedTextBoxquantity.Text), textBoxdes.Text, loc);
                dataGridViewItem.AutoGenerateColumns = false;
                dataGridViewItem.DataSource = d;
                textBoxName.Clear();
                maskedTextBoxquantity.Clear(); maskedTextBoxrate.Clear();
                textBoxdes.Clear(); comboBoxitcat.Text = "";
                picitem.Visible = false;
                MessageBox.Show("Data Inserted.");
            }

        }

        private void buttonupload_Click(object sender, EventArgs e)
        {
            picitem.Visible = true;
            OpenFileDialog o = new OpenFileDialog();
            if (o.ShowDialog() == DialogResult.OK)
            {
                textBoxpath.Text = o.FileName;
                picitem.Image = new Bitmap(o.FileName);
                picitem.SizeMode = PictureBoxSizeMode.Zoom;

            }
        }

        //private void buttonsavepic_Click(object sender, EventArgs e)
        //{
        //    OpenFileDialog o = new OpenFileDialog();
        //    textBoxpath.Text = o.FileName;
        //    File.Copy(Path.Combine(textBoxpath.Text), Path.Combine(Application.StartupPath + @"\Images", Path.GetFileName(textBoxpath.Text)), true);
        //    MessageBox.Show("The image is Saved");
        //}

        private void buttonAddc_Click(object sender, EventArgs e)
        {
            Item_Class i = new Item_Class();
            DataTable d = i.Add_Category(textBoxType.Text);
            dvgc.DataSource = d;
            textBoxType.Clear();
            MessageBox.Show("Data Inserted");
        }
        private void comboBoxicat_MouseHover(object sender, EventArgs e)
        {
            comboBoxitcat.Items.Clear();
            DataTable dt = SqlConnect.fetch("select name from item_category");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBoxitcat.Items.Add(dt.Rows[i][0].ToString());
            }
        }

        private void buttonCaup_Click(object sender, EventArgs e)
        {
            Item_Class i = new Item_Class();
            DataTable dt = i.up_category(int.Parse(cbs.Text), tbname.Text);
            dvgc.AutoGenerateColumns = false;
            dvgc.DataSource = dt;
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            Item_Class i = new Item_Class();
            if (cbcol.Text == "Item Category")
            {
                textBox2data.Visible = false;
                cbuic.Visible = true;
                SqlConnect.Save("Update Item set Item_Category='" + cbuic.Text.ToString() + "' where Item_ID='" + int.Parse(cbsea.Text) + "'");
            }
            else
            {
                string loc = "";
                textBox2data.Visible = true;
                cbuic.Visible = false;
                try
                {
                    loc = Path.Combine(Application.StartupPath + @"\Images", Path.GetFileName(textBoxpath.Text));
                    File.Copy(Path.Combine(textBoxpath.Text), loc, true);
                    textBoxpath.Text = loc;
                }
                catch (Exception ex)
                {

                    loc = "";

                }
                i.update_Item(cbsea.Text, cbcol.Text, textBox2data.Text, loc);
                DataTable d = SqlConnect.fetch("Select *from Item");
                dataGridViewItem.AutoGenerateColumns = false;
                dataGridViewItem.DataSource = d;
            }
        }

        private void comboBoxsearch_MouseHover(object sender, EventArgs e)
        {
            cbsea.Items.Clear();
            DataTable dt = SqlConnect.fetch("select Item_Name from Item");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                cbsea.Items.Add(dt.Rows[i][0].ToString());
            }
        }

        private void comboBoxdel_MouseHover(object sender, EventArgs e)
        {
            cbdel.Items.Clear();
            DataTable dt = SqlConnect.fetch("select Item_Name from Item");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                cbdel.Items.Add(dt.Rows[i][0].ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        private void cbs_MouseHover(object sender, EventArgs e)
        {
            cbs.Items.Clear();
            DataTable dt = SqlConnect.fetch("select ID from Item_Category");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                cbs.Items.Add(dt.Rows[i][0].ToString());
            }
        }

        private void comboBox4_MouseHover(object sender, EventArgs e)
        {
            cbxdel.Items.Clear();
            DataTable dt = SqlConnect.fetch("select ID from Item_Category");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                cbxdel.Items.Add(dt.Rows[i][0].ToString());
            }
        }

        private void bdel_Click(object sender, EventArgs e)
        {
            Item_Class i = new Item_Class();
            DataTable dt = i.delete(cbdel.Text);
            dvgc.AutoGenerateColumns = false;
            dvgc.DataSource = dt;

        }
        private void icdel_Click(object sender, EventArgs e)
        {
            int a = int.Parse(cbxdel.Text);
            Item_Class i = new Item_Class();
            DataTable d = i.del_ca(a);
            
            dvgc.DataSource = d;
            MessageBox.Show("Deleted Successfully.");

        }


        private void cbuic_MouseHover(object sender, EventArgs e)
        {
            try
            {
                cbs.Items.Clear();
                DataTable dt = SqlConnect.fetch("select ID from Item_Category");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    cbs.Items.Add(dt.Rows[i][0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonupdate_MouseHover(object sender, EventArgs e)
        {
            if (cbcol.Text == "Item Category")
            {
                textBox2data.Visible = false;
                cbuic.Visible = true;
            }
            else
            {
                textBox2data.Visible = true;
                cbuic.Visible = false;
            }
        }
    }
}
