﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test
{
    public partial class PI2 : Form
    {
        public PI2()
        {
            InitializeComponent();
        }

        private void PI2_Load(object sender, EventArgs e)
        {

        }

        private void cbd_MouseHover(object sender, EventArgs e)
        {
            try
            {

                cbd.Items.Clear();
                DataTable dt = SqlConnect.fetch("select Customer_ID from Customer");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    cbd.Items.Add(dt.Rows[i][0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable t = SqlConnect.fetch("select *from Purchased_Item_Detail");
            dgvitem.AutoGenerateColumns = false;
            dgvitem.DataSource = t;
        }

        private void ucb_MouseHover(object sender, EventArgs e)
        {
            try
            {
                ucb.Items.Clear();
                DataTable dt = SqlConnect.fetch("select Customer_ID from Customer");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    cbd.Items.Add(dt.Rows[i][0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Purchase_Item p = new Purchase_Item();
            p.Show();
            this.Hide();
        }

        private void bdu_MouseHover(object sender, EventArgs e)
        {
            DataGridViewComboBoxColumn com = new DataGridViewComboBoxColumn();
            DataTable dt = SqlConnect.fetch("select item_name from item ");

            com.HeaderText = "Items";
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                com.Items.Add(dt.Rows[i][0].ToString());
            }
            dgvitem.Columns.Add(com);
            DataGridViewComboBoxColumn com1 = new DataGridViewComboBoxColumn();

            DataTable dt1 = SqlConnect.fetch("select name from services ");
            com1.HeaderText = "Service";
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                com1.Items.Add(dt1.Rows[i][0].ToString());
            }
            dgvitem.Columns.Add(com1);

            dgvitem.ColumnCount = 9;
            dgvitem.Columns[3].HeaderText = "S.Charge";

            // dgvitem.ColumnCount = 9;


            dgvitem.Columns[4].HeaderText = "Quantity of item";
            dgvitem.Columns[5].HeaderText = "Rate";
            dgvitem.Columns[6].HeaderText = "Amount";
            dgvitem.Columns[7].HeaderText = "Date";
            dgvitem.Columns[8].HeaderText = "Status";

        }
        private void SERVICE(object sender, DataGridViewCellEventArgs e)
        {
            int amount = 0;
            try
            {
                amount = int.Parse(dgvitem.Rows[e.RowIndex].Cells[4].Value.ToString()) * int.Parse(dgvitem.Rows[e.RowIndex].Cells[5].Value.ToString());
                amount = amount + int.Parse(dgvitem.Rows[e.RowIndex].Cells[3].Value.ToString());
                dgvitem.Rows[e.RowIndex].Cells[6].Value = amount;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
