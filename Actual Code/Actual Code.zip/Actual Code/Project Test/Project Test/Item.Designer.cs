﻿namespace Project_Test
{
    partial class Item
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Item));
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonItemcateg = new System.Windows.Forms.Button();
            this.button8Itemreg = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.itemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cNG_Kits_Cylinders_PartsDataSet4 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet4();
            this.itemCategoryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cNG_Kits_Cylinders_PartsDataSet3 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet3();
            this.itemCategoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cNG_Kits_Cylinders_PartsDataSet2 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet2();
            this.item_CategoryTableAdapter = new Project_Test.CNG_Kits_Cylinders_PartsDataSet2TableAdapters.Item_CategoryTableAdapter();
            this.itemCategoryBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.cNG_Kits_Cylinders_PartsDataSet5 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet5();
            this.item_CategoryTableAdapter1 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet3TableAdapters.Item_CategoryTableAdapter();
            this.itemTableAdapter = new Project_Test.CNG_Kits_Cylinders_PartsDataSet4TableAdapters.ItemTableAdapter();
            this.item_CategoryTableAdapter2 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet5TableAdapters.Item_CategoryTableAdapter();
            this.cNG_Kits_Cylinders_PartsDataSet6 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet6();
            this.itemCategoryBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.item_CategoryTableAdapter3 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet6TableAdapters.Item_CategoryTableAdapter();
            this.panelitem = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.cbuic = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.bdel = new System.Windows.Forms.Button();
            this.cbdel = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox2data = new System.Windows.Forms.TextBox();
            this.cbcol = new System.Windows.Forms.ComboBox();
            this.maskedTextBoxrate = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxquantity = new System.Windows.Forms.MaskedTextBox();
            this.cbsea = new System.Windows.Forms.ComboBox();
            this.textBoxpath = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridViewItem = new System.Windows.Forms.DataGridView();
            this.textBoxdes = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonupload = new System.Windows.Forms.Button();
            this.picitem = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonupdate = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxitcat = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.itemCategoryBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.cNG_Kits_Cylinders_PartsDataSet7 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet7();
            this.item_CategoryTableAdapter4 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet7TableAdapters.Item_CategoryTableAdapter();
            this.cNG_Kits_Cylinders_PartsDataSet8 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet8();
            this.itemCategoryBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.item_CategoryTableAdapter5 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet8TableAdapters.Item_CategoryTableAdapter();
            this.panelitemcategory = new System.Windows.Forms.Panel();
            this.icdel = new System.Windows.Forms.Button();
            this.cbxdel = new System.Windows.Forms.ComboBox();
            this.tbname = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.buttonCaup = new System.Windows.Forms.Button();
            this.cbs = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxType = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dvgc = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonAddc = new System.Windows.Forms.Button();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource3)).BeginInit();
            this.panelitem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picitem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource5)).BeginInit();
            this.panelitemcategory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgc)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.buttonItemcateg);
            this.panel1.Controls.Add(this.button8Itemreg);
            this.panel1.Controls.Add(this.buttonExit);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(123, 596);
            this.panel1.TabIndex = 2;
            // 
            // buttonItemcateg
            // 
            this.buttonItemcateg.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonItemcateg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemcateg.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemcateg.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonItemcateg.Location = new System.Drawing.Point(-1, 261);
            this.buttonItemcateg.Name = "buttonItemcateg";
            this.buttonItemcateg.Size = new System.Drawing.Size(123, 56);
            this.buttonItemcateg.TabIndex = 4;
            this.buttonItemcateg.Text = "ITEM CATEGORY";
            this.buttonItemcateg.UseVisualStyleBackColor = false;
            this.buttonItemcateg.Click += new System.EventHandler(this.buttonItemcateg_Click);
            // 
            // button8Itemreg
            // 
            this.button8Itemreg.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.button8Itemreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8Itemreg.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8Itemreg.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button8Itemreg.Location = new System.Drawing.Point(-1, 181);
            this.button8Itemreg.Name = "button8Itemreg";
            this.button8Itemreg.Size = new System.Drawing.Size(123, 56);
            this.button8Itemreg.TabIndex = 3;
            this.button8Itemreg.Text = "ITEM REGIS.";
            this.button8Itemreg.UseVisualStyleBackColor = false;
            this.button8Itemreg.Click += new System.EventHandler(this.button8Itemreg_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonExit.Location = new System.Drawing.Point(-1, 358);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(123, 56);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "EXIT";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.GreenYellow;
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(123, 100);
            this.panel5.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 100);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(129, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(559, 100);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Yellow;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(123, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(977, 44);
            this.panel3.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("American Classic Extra Bold", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(31, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "ITEM COUNTER";
            // 
            // itemBindingSource
            // 
            this.itemBindingSource.DataMember = "Item";
            this.itemBindingSource.DataSource = this.cNG_Kits_Cylinders_PartsDataSet4;
            // 
            // cNG_Kits_Cylinders_PartsDataSet4
            // 
            this.cNG_Kits_Cylinders_PartsDataSet4.DataSetName = "CNG_Kits_Cylinders_PartsDataSet4";
            this.cNG_Kits_Cylinders_PartsDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemCategoryBindingSource1
            // 
            this.itemCategoryBindingSource1.DataMember = "Item_Category";
            this.itemCategoryBindingSource1.DataSource = this.cNG_Kits_Cylinders_PartsDataSet3;
            // 
            // cNG_Kits_Cylinders_PartsDataSet3
            // 
            this.cNG_Kits_Cylinders_PartsDataSet3.DataSetName = "CNG_Kits_Cylinders_PartsDataSet3";
            this.cNG_Kits_Cylinders_PartsDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemCategoryBindingSource
            // 
            this.itemCategoryBindingSource.DataMember = "Item_Category";
            this.itemCategoryBindingSource.DataSource = this.cNG_Kits_Cylinders_PartsDataSet2;
            // 
            // cNG_Kits_Cylinders_PartsDataSet2
            // 
            this.cNG_Kits_Cylinders_PartsDataSet2.DataSetName = "CNG_Kits_Cylinders_PartsDataSet2";
            this.cNG_Kits_Cylinders_PartsDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // item_CategoryTableAdapter
            // 
            this.item_CategoryTableAdapter.ClearBeforeFill = true;
            // 
            // itemCategoryBindingSource2
            // 
            this.itemCategoryBindingSource2.DataMember = "Item_Category";
            this.itemCategoryBindingSource2.DataSource = this.cNG_Kits_Cylinders_PartsDataSet5;
            // 
            // cNG_Kits_Cylinders_PartsDataSet5
            // 
            this.cNG_Kits_Cylinders_PartsDataSet5.DataSetName = "CNG_Kits_Cylinders_PartsDataSet5";
            this.cNG_Kits_Cylinders_PartsDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // item_CategoryTableAdapter1
            // 
            this.item_CategoryTableAdapter1.ClearBeforeFill = true;
            // 
            // itemTableAdapter
            // 
            this.itemTableAdapter.ClearBeforeFill = true;
            // 
            // item_CategoryTableAdapter2
            // 
            this.item_CategoryTableAdapter2.ClearBeforeFill = true;
            // 
            // cNG_Kits_Cylinders_PartsDataSet6
            // 
            this.cNG_Kits_Cylinders_PartsDataSet6.DataSetName = "CNG_Kits_Cylinders_PartsDataSet6";
            this.cNG_Kits_Cylinders_PartsDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemCategoryBindingSource3
            // 
            this.itemCategoryBindingSource3.DataMember = "Item_Category";
            this.itemCategoryBindingSource3.DataSource = this.cNG_Kits_Cylinders_PartsDataSet6;
            // 
            // item_CategoryTableAdapter3
            // 
            this.item_CategoryTableAdapter3.ClearBeforeFill = true;
            // 
            // panelitem
            // 
            this.panelitem.Controls.Add(this.comboBox1);
            this.panelitem.Controls.Add(this.cbuic);
            this.panelitem.Controls.Add(this.label17);
            this.panelitem.Controls.Add(this.bdel);
            this.panelitem.Controls.Add(this.cbdel);
            this.panelitem.Controls.Add(this.label10);
            this.panelitem.Controls.Add(this.label6);
            this.panelitem.Controls.Add(this.textBox2data);
            this.panelitem.Controls.Add(this.cbcol);
            this.panelitem.Controls.Add(this.maskedTextBoxrate);
            this.panelitem.Controls.Add(this.maskedTextBoxquantity);
            this.panelitem.Controls.Add(this.cbsea);
            this.panelitem.Controls.Add(this.textBoxpath);
            this.panelitem.Controls.Add(this.label8);
            this.panelitem.Controls.Add(this.label11);
            this.panelitem.Controls.Add(this.dataGridViewItem);
            this.panelitem.Controls.Add(this.textBoxdes);
            this.panelitem.Controls.Add(this.label7);
            this.panelitem.Controls.Add(this.buttonupload);
            this.panelitem.Controls.Add(this.picitem);
            this.panelitem.Controls.Add(this.label3);
            this.panelitem.Controls.Add(this.buttonupdate);
            this.panelitem.Controls.Add(this.label9);
            this.panelitem.Controls.Add(this.comboBoxitcat);
            this.panelitem.Controls.Add(this.label1);
            this.panelitem.Controls.Add(this.buttonAdd);
            this.panelitem.Controls.Add(this.textBoxName);
            this.panelitem.Controls.Add(this.label4);
            this.panelitem.Controls.Add(this.label2);
            this.panelitem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelitem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panelitem.Location = new System.Drawing.Point(123, 44);
            this.panelitem.Name = "panelitem";
            this.panelitem.Size = new System.Drawing.Size(977, 552);
            this.panelitem.TabIndex = 300;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(195, 673);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(172, 21);
            this.comboBox1.TabIndex = 309;
            // 
            // cbuic
            // 
            this.cbuic.FormattingEnabled = true;
            this.cbuic.Location = new System.Drawing.Point(191, 469);
            this.cbuic.Name = "cbuic";
            this.cbuic.Size = new System.Drawing.Size(172, 21);
            this.cbuic.TabIndex = 308;
            this.cbuic.MouseHover += new System.EventHandler(this.cbuic_MouseHover);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label17.Location = new System.Drawing.Point(22, 329);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(138, 19);
            this.label17.TabIndex = 307;
            this.label17.Text = "UPDATE INFO:";
            // 
            // bdel
            // 
            this.bdel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bdel.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdel.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.bdel.Location = new System.Drawing.Point(564, 304);
            this.bdel.Name = "bdel";
            this.bdel.Size = new System.Drawing.Size(118, 23);
            this.bdel.TabIndex = 306;
            this.bdel.Text = "DELETE";
            this.bdel.UseVisualStyleBackColor = true;
            this.bdel.Click += new System.EventHandler(this.bdel_Click);
            // 
            // cbdel
            // 
            this.cbdel.FormattingEnabled = true;
            this.cbdel.Location = new System.Drawing.Point(514, 267);
            this.cbdel.Name = "cbdel";
            this.cbdel.Size = new System.Drawing.Size(168, 21);
            this.cbdel.TabIndex = 305;
            this.cbdel.MouseHover += new System.EventHandler(this.comboBoxdel_MouseHover);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label10.Location = new System.Drawing.Point(22, 407);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(148, 16);
            this.label10.TabIndex = 304;
            this.label10.Text = "SELECT COLUMN:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Location = new System.Drawing.Point(22, 457);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 16);
            this.label6.TabIndex = 303;
            this.label6.Text = "ENTER DATA:";
            // 
            // textBox2data
            // 
            this.textBox2data.Location = new System.Drawing.Point(191, 443);
            this.textBox2data.Name = "textBox2data";
            this.textBox2data.Size = new System.Drawing.Size(172, 20);
            this.textBox2data.TabIndex = 302;
            // 
            // cbcol
            // 
            this.cbcol.FormattingEnabled = true;
            this.cbcol.Items.AddRange(new object[] {
            "Item Name",
            "Item Description",
            "Quantity",
            "Rate",
            "Item Category",
            "Image"});
            this.cbcol.Location = new System.Drawing.Point(191, 402);
            this.cbcol.Name = "cbcol";
            this.cbcol.Size = new System.Drawing.Size(172, 21);
            this.cbcol.TabIndex = 301;
            // 
            // maskedTextBoxrate
            // 
            this.maskedTextBoxrate.Location = new System.Drawing.Point(191, 105);
            this.maskedTextBoxrate.Mask = "000000000";
            this.maskedTextBoxrate.Name = "maskedTextBoxrate";
            this.maskedTextBoxrate.Size = new System.Drawing.Size(168, 20);
            this.maskedTextBoxrate.TabIndex = 300;
            // 
            // maskedTextBoxquantity
            // 
            this.maskedTextBoxquantity.Location = new System.Drawing.Point(191, 161);
            this.maskedTextBoxquantity.Mask = "00000";
            this.maskedTextBoxquantity.Name = "maskedTextBoxquantity";
            this.maskedTextBoxquantity.Size = new System.Drawing.Size(168, 20);
            this.maskedTextBoxquantity.TabIndex = 299;
            this.maskedTextBoxquantity.ValidatingType = typeof(int);
            // 
            // cbsea
            // 
            this.cbsea.FormattingEnabled = true;
            this.cbsea.Location = new System.Drawing.Point(191, 361);
            this.cbsea.Name = "cbsea";
            this.cbsea.Size = new System.Drawing.Size(172, 21);
            this.cbsea.TabIndex = 297;
            this.cbsea.MouseHover += new System.EventHandler(this.comboBoxsearch_MouseHover);
            // 
            // textBoxpath
            // 
            this.textBoxpath.Location = new System.Drawing.Point(710, 37);
            this.textBoxpath.Name = "textBoxpath";
            this.textBoxpath.Size = new System.Drawing.Size(167, 20);
            this.textBoxpath.TabIndex = 295;
            this.textBoxpath.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Location = new System.Drawing.Point(392, 269);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 16);
            this.label8.TabIndex = 291;
            this.label8.Text = "DELETE:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label11.Location = new System.Drawing.Point(22, 363);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 16);
            this.label11.TabIndex = 289;
            this.label11.Text = "SEARCH:";
            // 
            // dataGridViewItem
            // 
            this.dataGridViewItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewItem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column6,
            this.Column3,
            this.Column5,
            this.Column4});
            this.dataGridViewItem.Location = new System.Drawing.Point(408, 363);
            this.dataGridViewItem.Name = "dataGridViewItem";
            this.dataGridViewItem.Size = new System.Drawing.Size(531, 177);
            this.dataGridViewItem.TabIndex = 287;
            // 
            // textBoxdes
            // 
            this.textBoxdes.Location = new System.Drawing.Point(478, 78);
            this.textBoxdes.Multiline = true;
            this.textBoxdes.Name = "textBoxdes";
            this.textBoxdes.Size = new System.Drawing.Size(200, 76);
            this.textBoxdes.TabIndex = 286;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(475, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 16);
            this.label7.TabIndex = 285;
            this.label7.Text = "DESCRIPTION:";
            // 
            // buttonupload
            // 
            this.buttonupload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonupload.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonupload.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonupload.Location = new System.Drawing.Point(710, 269);
            this.buttonupload.Name = "buttonupload";
            this.buttonupload.Size = new System.Drawing.Size(174, 23);
            this.buttonupload.TabIndex = 283;
            this.buttonupload.Text = "UPLOAD IMAGE";
            this.buttonupload.UseVisualStyleBackColor = true;
            this.buttonupload.Click += new System.EventHandler(this.buttonupload_Click);
            // 
            // picitem
            // 
            this.picitem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picitem.Location = new System.Drawing.Point(710, 78);
            this.picitem.Name = "picitem";
            this.picitem.Size = new System.Drawing.Size(249, 169);
            this.picitem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picitem.TabIndex = 282;
            this.picitem.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("American Classic", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(347, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(248, 24);
            this.label3.TabIndex = 279;
            this.label3.Text = "ITEM REGISTIRATION";
            // 
            // buttonupdate
            // 
            this.buttonupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonupdate.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonupdate.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonupdate.Location = new System.Drawing.Point(245, 496);
            this.buttonupdate.Name = "buttonupdate";
            this.buttonupdate.Size = new System.Drawing.Size(118, 23);
            this.buttonupdate.TabIndex = 278;
            this.buttonupdate.Text = "UPDATE";
            this.buttonupdate.UseVisualStyleBackColor = true;
            this.buttonupdate.Click += new System.EventHandler(this.buttonupdate_Click);
            this.buttonupdate.MouseHover += new System.EventHandler(this.buttonupdate_MouseHover);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Location = new System.Drawing.Point(22, 161);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 15);
            this.label9.TabIndex = 274;
            this.label9.Text = "QUANTITY:";
            // 
            // comboBoxitcat
            // 
            this.comboBoxitcat.FormattingEnabled = true;
            this.comboBoxitcat.Location = new System.Drawing.Point(191, 133);
            this.comboBoxitcat.Name = "comboBoxitcat";
            this.comboBoxitcat.Size = new System.Drawing.Size(168, 21);
            this.comboBoxitcat.TabIndex = 272;
            this.comboBoxitcat.MouseHover += new System.EventHandler(this.comboBoxicat_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(22, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 15);
            this.label1.TabIndex = 271;
            this.label1.Text = "ITEM CATEGORY:";
            // 
            // buttonAdd
            // 
            this.buttonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAdd.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdd.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonAdd.Location = new System.Drawing.Point(241, 200);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(118, 23);
            this.buttonAdd.TabIndex = 268;
            this.buttonAdd.Text = "ADD";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(191, 81);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(168, 20);
            this.textBoxName.TabIndex = 266;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(22, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 15);
            this.label4.TabIndex = 265;
            this.label4.Text = "RATE:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(22, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 15);
            this.label2.TabIndex = 264;
            this.label2.Text = "ITEM NAME:";
            // 
            // itemCategoryBindingSource4
            // 
            this.itemCategoryBindingSource4.DataMember = "Item_Category";
            this.itemCategoryBindingSource4.DataSource = this.cNG_Kits_Cylinders_PartsDataSet7;
            // 
            // cNG_Kits_Cylinders_PartsDataSet7
            // 
            this.cNG_Kits_Cylinders_PartsDataSet7.DataSetName = "CNG_Kits_Cylinders_PartsDataSet7";
            this.cNG_Kits_Cylinders_PartsDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // item_CategoryTableAdapter4
            // 
            this.item_CategoryTableAdapter4.ClearBeforeFill = true;
            // 
            // cNG_Kits_Cylinders_PartsDataSet8
            // 
            this.cNG_Kits_Cylinders_PartsDataSet8.DataSetName = "CNG_Kits_Cylinders_PartsDataSet8";
            this.cNG_Kits_Cylinders_PartsDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemCategoryBindingSource5
            // 
            this.itemCategoryBindingSource5.DataMember = "Item_Category";
            this.itemCategoryBindingSource5.DataSource = this.cNG_Kits_Cylinders_PartsDataSet8;
            // 
            // item_CategoryTableAdapter5
            // 
            this.item_CategoryTableAdapter5.ClearBeforeFill = true;
            // 
            // panelitemcategory
            // 
            this.panelitemcategory.Controls.Add(this.icdel);
            this.panelitemcategory.Controls.Add(this.cbxdel);
            this.panelitemcategory.Controls.Add(this.tbname);
            this.panelitemcategory.Controls.Add(this.label16);
            this.panelitemcategory.Controls.Add(this.buttonCaup);
            this.panelitemcategory.Controls.Add(this.cbs);
            this.panelitemcategory.Controls.Add(this.label12);
            this.panelitemcategory.Controls.Add(this.label13);
            this.panelitemcategory.Controls.Add(this.textBoxType);
            this.panelitemcategory.Controls.Add(this.label14);
            this.panelitemcategory.Controls.Add(this.label15);
            this.panelitemcategory.Controls.Add(this.dvgc);
            this.panelitemcategory.Controls.Add(this.buttonAddc);
            this.panelitemcategory.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panelitemcategory.Location = new System.Drawing.Point(189, 78);
            this.panelitemcategory.Name = "panelitemcategory";
            this.panelitemcategory.Size = new System.Drawing.Size(723, 392);
            this.panelitemcategory.TabIndex = 301;
            // 
            // icdel
            // 
            this.icdel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.icdel.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.icdel.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.icdel.Location = new System.Drawing.Point(236, 314);
            this.icdel.Name = "icdel";
            this.icdel.Size = new System.Drawing.Size(100, 23);
            this.icdel.TabIndex = 263;
            this.icdel.Text = "DELETE:";
            this.icdel.UseVisualStyleBackColor = true;
            this.icdel.Click += new System.EventHandler(this.icdel_Click);
            // 
            // cbxdel
            // 
            this.cbxdel.FormattingEnabled = true;
            this.cbxdel.Location = new System.Drawing.Point(49, 316);
            this.cbxdel.Name = "cbxdel";
            this.cbxdel.Size = new System.Drawing.Size(150, 21);
            this.cbxdel.TabIndex = 262;
            this.cbxdel.MouseHover += new System.EventHandler(this.comboBox4_MouseHover);
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(236, 186);
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(142, 20);
            this.tbname.TabIndex = 261;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label16.Location = new System.Drawing.Point(233, 167);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(96, 16);
            this.label16.TabIndex = 260;
            this.label16.Text = "New Name:";
            // 
            // buttonCaup
            // 
            this.buttonCaup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCaup.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCaup.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonCaup.Location = new System.Drawing.Point(484, 184);
            this.buttonCaup.Name = "buttonCaup";
            this.buttonCaup.Size = new System.Drawing.Size(100, 23);
            this.buttonCaup.TabIndex = 253;
            this.buttonCaup.Text = "UPDATE";
            this.buttonCaup.UseVisualStyleBackColor = true;
            this.buttonCaup.Click += new System.EventHandler(this.buttonCaup_Click);
            // 
            // cbs
            // 
            this.cbs.FormattingEnabled = true;
            this.cbs.Location = new System.Drawing.Point(49, 186);
            this.cbs.Name = "cbs";
            this.cbs.Size = new System.Drawing.Size(150, 21);
            this.cbs.TabIndex = 258;
            this.cbs.MouseHover += new System.EventHandler(this.cbs_MouseHover);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("American Classic", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label12.Location = new System.Drawing.Point(216, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(381, 24);
            this.label12.TabIndex = 256;
            this.label12.Text = "ITEM CATEGORY REGISTIRATION";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label13.Location = new System.Drawing.Point(46, 167);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 16);
            this.label13.TabIndex = 255;
            this.label13.Text = "SEARCH:";
            // 
            // textBoxType
            // 
            this.textBoxType.Location = new System.Drawing.Point(236, 110);
            this.textBoxType.Name = "textBoxType";
            this.textBoxType.Size = new System.Drawing.Size(142, 20);
            this.textBoxType.TabIndex = 252;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label14.Location = new System.Drawing.Point(46, 112);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(153, 16);
            this.label14.TabIndex = 251;
            this.label14.Text = "CATEGORY NAME:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label15.Location = new System.Drawing.Point(46, 295);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 16);
            this.label15.TabIndex = 249;
            this.label15.Text = "DELETE_ID:";
            // 
            // dvgc
            // 
            this.dvgc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dvgc.Location = new System.Drawing.Point(368, 237);
            this.dvgc.Name = "dvgc";
            this.dvgc.Size = new System.Drawing.Size(244, 130);
            this.dvgc.TabIndex = 247;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // buttonAddc
            // 
            this.buttonAddc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddc.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddc.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonAddc.Location = new System.Drawing.Point(484, 109);
            this.buttonAddc.Name = "buttonAddc";
            this.buttonAddc.Size = new System.Drawing.Size(100, 23);
            this.buttonAddc.TabIndex = 244;
            this.buttonAddc.Text = "ADD";
            this.buttonAddc.UseVisualStyleBackColor = true;
            this.buttonAddc.Click += new System.EventHandler(this.buttonAddc_Click);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Item_ID";
            this.Column1.HeaderText = "ITEM ID";
            this.Column1.Name = "Column1";
            this.Column1.Width = 50;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Item_Name";
            this.Column2.HeaderText = "ITEM  NAME";
            this.Column2.Name = "Column2";
            this.Column2.Width = 110;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "Item_Description";
            this.Column6.HeaderText = "ITEM DESCRIPTION";
            this.Column6.Name = "Column6";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Rate";
            this.Column3.HeaderText = "RATE";
            this.Column3.Name = "Column3";
            this.Column3.Width = 60;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "Quantity_in_Stock";
            this.Column5.HeaderText = "QUANTITY";
            this.Column5.Name = "Column5";
            this.Column5.Width = 75;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Item_Category";
            this.Column4.HeaderText = "ITEM CATEGORIES";
            this.Column4.Name = "Column4";
            // 
            // Item
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.ClientSize = new System.Drawing.Size(1100, 596);
            this.Controls.Add(this.panelitem);
            this.Controls.Add(this.panelitemcategory);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Item";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item";
            this.Load += new System.EventHandler(this.Item_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource3)).EndInit();
            this.panelitem.ResumeLayout(false);
            this.panelitem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picitem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemCategoryBindingSource5)).EndInit();
            this.panelitemcategory.ResumeLayout(false);
            this.panelitemcategory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgc)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button8Itemreg;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonItemcateg;
        private CNG_Kits_Cylinders_PartsDataSet2 cNG_Kits_Cylinders_PartsDataSet2;
        private System.Windows.Forms.BindingSource itemCategoryBindingSource;
        private CNG_Kits_Cylinders_PartsDataSet2TableAdapters.Item_CategoryTableAdapter item_CategoryTableAdapter;
        private CNG_Kits_Cylinders_PartsDataSet3 cNG_Kits_Cylinders_PartsDataSet3;
        private System.Windows.Forms.BindingSource itemCategoryBindingSource1;
        private CNG_Kits_Cylinders_PartsDataSet3TableAdapters.Item_CategoryTableAdapter item_CategoryTableAdapter1;
        private CNG_Kits_Cylinders_PartsDataSet4 cNG_Kits_Cylinders_PartsDataSet4;
        private System.Windows.Forms.BindingSource itemBindingSource;
        private CNG_Kits_Cylinders_PartsDataSet4TableAdapters.ItemTableAdapter itemTableAdapter;
        private CNG_Kits_Cylinders_PartsDataSet5 cNG_Kits_Cylinders_PartsDataSet5;
        private System.Windows.Forms.BindingSource itemCategoryBindingSource2;
        private CNG_Kits_Cylinders_PartsDataSet5TableAdapters.Item_CategoryTableAdapter item_CategoryTableAdapter2;
        private CNG_Kits_Cylinders_PartsDataSet6 cNG_Kits_Cylinders_PartsDataSet6;
        private System.Windows.Forms.BindingSource itemCategoryBindingSource3;
        private CNG_Kits_Cylinders_PartsDataSet6TableAdapters.Item_CategoryTableAdapter item_CategoryTableAdapter3;
        private System.Windows.Forms.Panel panelitem;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxrate;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxquantity;
        private System.Windows.Forms.ComboBox cbsea;
        private System.Windows.Forms.TextBox textBoxpath;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridViewItem;
        private System.Windows.Forms.TextBox textBoxdes;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonupload;
        private System.Windows.Forms.PictureBox picitem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonupdate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxitcat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox2data;
        private System.Windows.Forms.ComboBox cbcol;
        private CNG_Kits_Cylinders_PartsDataSet7 cNG_Kits_Cylinders_PartsDataSet7;
        private System.Windows.Forms.BindingSource itemCategoryBindingSource4;
        private CNG_Kits_Cylinders_PartsDataSet7TableAdapters.Item_CategoryTableAdapter item_CategoryTableAdapter4;
        private CNG_Kits_Cylinders_PartsDataSet8 cNG_Kits_Cylinders_PartsDataSet8;
        private System.Windows.Forms.BindingSource itemCategoryBindingSource5;
        private CNG_Kits_Cylinders_PartsDataSet8TableAdapters.Item_CategoryTableAdapter item_CategoryTableAdapter5;
        private System.Windows.Forms.Panel panelitemcategory;
        private System.Windows.Forms.Button buttonCaup;
        private System.Windows.Forms.ComboBox cbs;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxType;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView dvgc;
        private System.Windows.Forms.Button buttonAddc;
        private System.Windows.Forms.Button bdel;
        private System.Windows.Forms.ComboBox cbdel;
        private System.Windows.Forms.ComboBox cbxdel;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button icdel;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox cbuic;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}