﻿CREATE TABLE [dbo].[Customer] (
    [Customer_ID]  INT           NOT NULL IDENTITY,
    [Name]         NVARCHAR (50) NULL,
    [Phone_Number] NVARCHAR(50)           NOT NULL,
    [Veihcle_Name] NVARCHAR (50) NOT NULL,
    [Plate_Number] NVARCHAR (50) NOT NULL,
    [CNIC_Number]  NVARCHAR (50) NOT NULL,
    [Purchase_ID]  INT           NULL,
    [Image]        IMAGE         NULL,
    [Sales_ID]     INT           NULL,
    CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED ([Customer_ID] ASC),
    CONSTRAINT [FK_Customer_Purchased_Item] FOREIGN KEY ([Purchase_ID]) REFERENCES [dbo].[Purchased_Item] ([Purchase_ID]),
    CONSTRAINT [FK_Customer_Sales_Order] FOREIGN KEY ([Sales_ID]) REFERENCES [dbo].[Sales_Order] ([Sales_ID])
);

