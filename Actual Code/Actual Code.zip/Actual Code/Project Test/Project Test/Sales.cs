﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test
{
    public partial class Sales : Form
    {
        List<Panel> l_panel = new List<Panel>();
        int index;
        public Sales()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void panelsalesinvoice_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Sales_Load(object sender, EventArgs e)
        {
            l_panel.Add(panelsalesorder);
            l_panel.Add(panelsalesinvoice);
            l_panel.Add(panelorderpayment);
            l_panel[index].BringToFront();
        }
        
        private void panelorderpayment_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            if (index> 0)
            {
                l_panel[--index].BringToFront();
            }
        }

        private void panelorderpayment_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            if (index < l_panel.Count - 1)
                l_panel[++index].BringToFront();
        }
    }
}
