﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test
{
    class Services_Class : Services
    {
        public DataTable Add(string name, int amo)
        {
            try
            {
                SqlConnect.Save("Insert into Services (Name,Amount) values ('" + name + "','" + amo + "')");
                DataTable dt = SqlConnect.fetch("Select *From Services");
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
        public DataTable Del(int ser_id)
        {
            try
            {
                SqlConnect.Save("Delete from Services where Service_ID='" + ser_id + "'");
                DataTable dt = SqlConnect.fetch("Select *from Services");
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
        public DataTable UpdateN(int ser_id,string n)
        {
            try
            {
                SqlConnect.Save("Update Services set Name='"+n+"' where Service_ID='" + ser_id + "'");
                DataTable dt = SqlConnect.fetch("Select *from Services");
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
        public DataTable Updatepr(int ser_id,int p)
        {
            try
            {
                SqlConnect.Save("Update Services set Amount='"+p+"' where Service_ID='" +ser_id+ "'");
                DataTable dt = SqlConnect.fetch("Select *from Services");
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
    }
}
