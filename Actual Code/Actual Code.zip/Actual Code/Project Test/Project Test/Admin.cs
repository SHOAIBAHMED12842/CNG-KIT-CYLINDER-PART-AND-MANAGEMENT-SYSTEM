﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Purchase_Item p = new Purchase_Item();
            p.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Customer c = new Customer();
            c.Show();
            this.Hide();
        }
        
        private void Admin_Load(object sender, EventArgs e)
        {

        }

        private void buttonPurchaseItem_Click(object sender, EventArgs e)
        {
            Purchase_Item p = new Purchase_Item();
            p.Show();
            this.Hide();
        }

        private void buttonServices_Click(object sender, EventArgs e)
        {
            Services s = new Services();
            s.Show();
            this.Close();
        }

        private void buttonVendor_Click(object sender, EventArgs e)
        {
            Vendor v = new Vendor();
            v.Show();
            this.Close();
        }

        private void buttonSales_Click(object sender, EventArgs e)
        {
            Sales s = new Sales();
            s.Show();
            this.Close();
        }

        private void buttonCustomer_Click(object sender, EventArgs e)
        {
            Customer c = new Customer();
            c.Show();
            this.Close();
        }

        private void buttonItem_Click(object sender, EventArgs e)
        {
            Item i = new Item();
            i.Show();
            this.Close();
        }

        private void buttonHelp_Click(object sender, EventArgs e)
        {
            panelHelp.Show();
            panelHelp.BringToFront();
        }

        private void buttonExitHelp_Click(object sender, EventArgs e)
        {
            panelHelp.SendToBack();
        }
    }
}
