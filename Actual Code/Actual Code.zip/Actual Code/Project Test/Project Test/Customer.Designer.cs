﻿namespace Project_Test
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer));
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonSO = new System.Windows.Forms.Button();
            this.buttonPIT = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panelcustomer = new System.Windows.Forms.Panel();
            this.cbid = new System.Windows.Forms.ComboBox();
            this.cbdel = new System.Windows.Forms.ComboBox();
            this.cbupdate = new System.Windows.Forms.ComboBox();
            this.buttonupdate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbp = new System.Windows.Forms.TextBox();
            this.bs = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonslist = new System.Windows.Forms.Button();
            this.textBoxpic = new System.Windows.Forms.TextBox();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.label44 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.buttonDel = new System.Windows.Forms.Button();
            this.dataGridViewcustomer = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonImage = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label36 = new System.Windows.Forms.Label();
            this.maskedTextBoxCNIC = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxPhone = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxPname = new System.Windows.Forms.MaskedTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBoxVName = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panelcustomer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewcustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.buttonSO);
            this.panel1.Controls.Add(this.buttonPIT);
            this.panel1.Controls.Add(this.buttonE);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(123, 584);
            this.panel1.TabIndex = 271;
            // 
            // buttonSO
            // 
            this.buttonSO.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonSO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSO.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSO.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonSO.Location = new System.Drawing.Point(-1, 169);
            this.buttonSO.Name = "buttonSO";
            this.buttonSO.Size = new System.Drawing.Size(123, 66);
            this.buttonSO.TabIndex = 5;
            this.buttonSO.Text = "SALES ORDER";
            this.buttonSO.UseVisualStyleBackColor = false;
            this.buttonSO.Click += new System.EventHandler(this.buttonSO_Click);
            // 
            // buttonPIT
            // 
            this.buttonPIT.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonPIT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPIT.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPIT.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonPIT.Location = new System.Drawing.Point(-1, 287);
            this.buttonPIT.Name = "buttonPIT";
            this.buttonPIT.Size = new System.Drawing.Size(123, 66);
            this.buttonPIT.TabIndex = 4;
            this.buttonPIT.Text = "PURCHASE ITEM";
            this.buttonPIT.UseVisualStyleBackColor = false;
            this.buttonPIT.Click += new System.EventHandler(this.buttonPIT_Click);
            // 
            // buttonE
            // 
            this.buttonE.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonE.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonE.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonE.Location = new System.Drawing.Point(-1, 400);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(123, 56);
            this.buttonE.TabIndex = 2;
            this.buttonE.Text = "EXIT";
            this.buttonE.UseVisualStyleBackColor = false;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.GreenYellow;
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(123, 100);
            this.panel5.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 100);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Yellow;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(123, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1027, 44);
            this.panel3.TabIndex = 272;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("American Classic Extra Bold", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(426, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "CUSTOMER REGISTRATION COUNTER";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // panelcustomer
            // 
            this.panelcustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.panelcustomer.Controls.Add(this.cbid);
            this.panelcustomer.Controls.Add(this.cbdel);
            this.panelcustomer.Controls.Add(this.cbupdate);
            this.panelcustomer.Controls.Add(this.buttonupdate);
            this.panelcustomer.Controls.Add(this.label1);
            this.panelcustomer.Controls.Add(this.tbp);
            this.panelcustomer.Controls.Add(this.bs);
            this.panelcustomer.Controls.Add(this.label8);
            this.panelcustomer.Controls.Add(this.buttonslist);
            this.panelcustomer.Controls.Add(this.textBoxpic);
            this.panelcustomer.Controls.Add(this.buttonSearch);
            this.panelcustomer.Controls.Add(this.label44);
            this.panelcustomer.Controls.Add(this.label42);
            this.panelcustomer.Controls.Add(this.label43);
            this.panelcustomer.Controls.Add(this.buttonDel);
            this.panelcustomer.Controls.Add(this.dataGridViewcustomer);
            this.panelcustomer.Controls.Add(this.buttonImage);
            this.panelcustomer.Controls.Add(this.pictureBox2);
            this.panelcustomer.Controls.Add(this.label36);
            this.panelcustomer.Controls.Add(this.maskedTextBoxCNIC);
            this.panelcustomer.Controls.Add(this.maskedTextBoxPhone);
            this.panelcustomer.Controls.Add(this.maskedTextBoxPname);
            this.panelcustomer.Controls.Add(this.label37);
            this.panelcustomer.Controls.Add(this.textBoxVName);
            this.panelcustomer.Controls.Add(this.textBoxName);
            this.panelcustomer.Controls.Add(this.label38);
            this.panelcustomer.Controls.Add(this.label39);
            this.panelcustomer.Controls.Add(this.label40);
            this.panelcustomer.Controls.Add(this.label41);
            this.panelcustomer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelcustomer.Location = new System.Drawing.Point(123, 44);
            this.panelcustomer.Name = "panelcustomer";
            this.panelcustomer.Size = new System.Drawing.Size(1027, 540);
            this.panelcustomer.TabIndex = 275;
            // 
            // cbid
            // 
            this.cbid.FormattingEnabled = true;
            this.cbid.Items.AddRange(new object[] {
            "Customer Name",
            "CNIC Number",
            "Phone Number",
            "Vehicle Name",
            "Plate Number"});
            this.cbid.Location = new System.Drawing.Point(136, 298);
            this.cbid.Name = "cbid";
            this.cbid.Size = new System.Drawing.Size(164, 21);
            this.cbid.TabIndex = 276;
            this.cbid.MouseHover += new System.EventHandler(this.comboBox2_MouseHover);
            // 
            // cbdel
            // 
            this.cbdel.FormattingEnabled = true;
            this.cbdel.Items.AddRange(new object[] {
            "Customer Name",
            "CNIC Number",
            "Phone Number",
            "Vehicle Name",
            "Plate Number"});
            this.cbdel.Location = new System.Drawing.Point(136, 476);
            this.cbdel.Name = "cbdel";
            this.cbdel.Size = new System.Drawing.Size(164, 21);
            this.cbdel.TabIndex = 275;
            this.cbdel.MouseHover += new System.EventHandler(this.cbdel_MouseHover);
            // 
            // cbupdate
            // 
            this.cbupdate.FormattingEnabled = true;
            this.cbupdate.Items.AddRange(new object[] {
            "Customer Name",
            "CNIC Number",
            "Phone Number",
            "Vehicle Name",
            "Plate Number",
            "Image"});
            this.cbupdate.Location = new System.Drawing.Point(136, 376);
            this.cbupdate.Name = "cbupdate";
            this.cbupdate.Size = new System.Drawing.Size(164, 21);
            this.cbupdate.TabIndex = 274;
            // 
            // buttonupdate
            // 
            this.buttonupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonupdate.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonupdate.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonupdate.Location = new System.Drawing.Point(168, 442);
            this.buttonupdate.Name = "buttonupdate";
            this.buttonupdate.Size = new System.Drawing.Size(94, 23);
            this.buttonupdate.TabIndex = 273;
            this.buttonupdate.Text = "UPDATE";
            this.buttonupdate.UseVisualStyleBackColor = true;
            this.buttonupdate.Click += new System.EventHandler(this.buttonupdate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(27, 381);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 16);
            this.label1.TabIndex = 272;
            this.label1.Text = "UPDATE:";
            // 
            // tbp
            // 
            this.tbp.Location = new System.Drawing.Point(136, 416);
            this.tbp.Name = "tbp";
            this.tbp.Size = new System.Drawing.Size(164, 20);
            this.tbp.TabIndex = 271;
            // 
            // bs
            // 
            this.bs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bs.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bs.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.bs.Location = new System.Drawing.Point(38, 221);
            this.bs.Name = "bs";
            this.bs.Size = new System.Drawing.Size(152, 23);
            this.bs.TabIndex = 270;
            this.bs.Text = "SAVE";
            this.bs.UseVisualStyleBackColor = true;
            this.bs.Click += new System.EventHandler(this.bs_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Location = new System.Drawing.Point(380, 270);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(170, 16);
            this.label8.TabIndex = 269;
            this.label8.Text = "LIST OF CUSTOMER:";
            // 
            // buttonslist
            // 
            this.buttonslist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonslist.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonslist.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonslist.Location = new System.Drawing.Point(570, 267);
            this.buttonslist.Name = "buttonslist";
            this.buttonslist.Size = new System.Drawing.Size(178, 23);
            this.buttonslist.TabIndex = 268;
            this.buttonslist.Text = "SHOW LIST";
            this.buttonslist.UseVisualStyleBackColor = true;
            this.buttonslist.Click += new System.EventHandler(this.buttonslist_Click);
            // 
            // textBoxpic
            // 
            this.textBoxpic.Location = new System.Drawing.Point(692, 49);
            this.textBoxpic.Name = "textBoxpic";
            this.textBoxpic.Size = new System.Drawing.Size(167, 20);
            this.textBoxpic.TabIndex = 267;
            // 
            // buttonSearch
            // 
            this.buttonSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSearch.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSearch.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonSearch.Location = new System.Drawing.Point(168, 325);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(94, 23);
            this.buttonSearch.TabIndex = 266;
            this.buttonSearch.Text = "SEARCH";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label44.Location = new System.Drawing.Point(546, 75);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(64, 16);
            this.label44.TabIndex = 265;
            this.label44.Text = "IMAGE:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label42.Location = new System.Drawing.Point(29, 476);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(75, 16);
            this.label42.TabIndex = 263;
            this.label42.Text = "DELETE:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label43.Location = new System.Drawing.Point(27, 300);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(79, 16);
            this.label43.TabIndex = 261;
            this.label43.Text = "SEARCH:";
            // 
            // buttonDel
            // 
            this.buttonDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDel.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDel.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonDel.Location = new System.Drawing.Point(94, 503);
            this.buttonDel.Name = "buttonDel";
            this.buttonDel.Size = new System.Drawing.Size(94, 28);
            this.buttonDel.TabIndex = 260;
            this.buttonDel.Text = "DELETE ALL";
            this.buttonDel.UseVisualStyleBackColor = true;
            this.buttonDel.Click += new System.EventHandler(this.buttonDel_Click);
            // 
            // dataGridViewcustomer
            // 
            this.dataGridViewcustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewcustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.dataGridViewcustomer.Location = new System.Drawing.Point(383, 317);
            this.dataGridViewcustomer.Name = "dataGridViewcustomer";
            this.dataGridViewcustomer.Size = new System.Drawing.Size(632, 184);
            this.dataGridViewcustomer.TabIndex = 258;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "customer_id";
            this.dataGridViewTextBoxColumn13.HeaderText = "CUSTOMER ID";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn14.HeaderText = "CUSTOMER NAME";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "CNIC_Number";
            this.dataGridViewTextBoxColumn15.HeaderText = "CNIC NO";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Veihcle_Name";
            this.dataGridViewTextBoxColumn16.HeaderText = "VEHICLE NAME";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Plate_Number";
            this.dataGridViewTextBoxColumn17.HeaderText = "PLATE NO";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Phone_number";
            this.dataGridViewTextBoxColumn18.HeaderText = "PHONE NO";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // buttonImage
            // 
            this.buttonImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonImage.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonImage.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonImage.Location = new System.Drawing.Point(549, 115);
            this.buttonImage.Name = "buttonImage";
            this.buttonImage.Size = new System.Drawing.Size(152, 23);
            this.buttonImage.TabIndex = 255;
            this.buttonImage.Text = "UPLOAD IMAGE";
            this.buttonImage.UseVisualStyleBackColor = true;
            this.buttonImage.Click += new System.EventHandler(this.buttonImage_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(744, 75);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(249, 169);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 254;
            this.pictureBox2.TabStop = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("American Classic", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label36.Location = new System.Drawing.Point(350, 20);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(318, 24);
            this.label36.TabIndex = 253;
            this.label36.Text = "CUSTOMER REGISTIRATION";
            // 
            // maskedTextBoxCNIC
            // 
            this.maskedTextBoxCNIC.Location = new System.Drawing.Point(241, 178);
            this.maskedTextBoxCNIC.Mask = "00000-0000000-0";
            this.maskedTextBoxCNIC.Name = "maskedTextBoxCNIC";
            this.maskedTextBoxCNIC.Size = new System.Drawing.Size(166, 20);
            this.maskedTextBoxCNIC.TabIndex = 252;
            // 
            // maskedTextBoxPhone
            // 
            this.maskedTextBoxPhone.Location = new System.Drawing.Point(241, 150);
            this.maskedTextBoxPhone.Mask = "0000000000";
            this.maskedTextBoxPhone.Name = "maskedTextBoxPhone";
            this.maskedTextBoxPhone.Size = new System.Drawing.Size(166, 20);
            this.maskedTextBoxPhone.TabIndex = 251;
            // 
            // maskedTextBoxPname
            // 
            this.maskedTextBoxPname.Location = new System.Drawing.Point(241, 119);
            this.maskedTextBoxPname.Mask = "AAA-000";
            this.maskedTextBoxPname.Name = "maskedTextBoxPname";
            this.maskedTextBoxPname.Size = new System.Drawing.Size(166, 20);
            this.maskedTextBoxPname.TabIndex = 250;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label37.Location = new System.Drawing.Point(35, 180);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(79, 16);
            this.label37.TabIndex = 249;
            this.label37.Text = "CNIC NO:";
            // 
            // textBoxVName
            // 
            this.textBoxVName.Location = new System.Drawing.Point(240, 89);
            this.textBoxVName.Name = "textBoxVName";
            this.textBoxVName.Size = new System.Drawing.Size(167, 20);
            this.textBoxVName.TabIndex = 245;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(239, 58);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(167, 20);
            this.textBoxName.TabIndex = 244;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label38.Location = new System.Drawing.Point(35, 152);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(96, 16);
            this.label38.TabIndex = 243;
            this.label38.Text = "PHONE NO:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label39.Location = new System.Drawing.Point(34, 121);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(94, 16);
            this.label39.TabIndex = 242;
            this.label39.Text = "PLATE NO:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label40.Location = new System.Drawing.Point(34, 93);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(134, 16);
            this.label40.TabIndex = 241;
            this.label40.Text = "VEHICLE NAME:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label41.Location = new System.Drawing.Point(35, 62);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(153, 16);
            this.label41.TabIndex = 240;
            this.label41.Text = "CUSTOMER NAME:";
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1150, 584);
            this.Controls.Add(this.panelcustomer);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Customer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer";
            this.Load += new System.EventHandler(this.Customer_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panelcustomer.ResumeLayout(false);
            this.panelcustomer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewcustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonSO;
        private System.Windows.Forms.Button buttonPIT;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panelcustomer;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonslist;
        private System.Windows.Forms.TextBox textBoxpic;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button buttonDel;
        private System.Windows.Forms.DataGridView dataGridViewcustomer;
        private System.Windows.Forms.Button buttonImage;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxCNIC;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPhone;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPname;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBoxVName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button bs;
        private System.Windows.Forms.ComboBox cbupdate;
        private System.Windows.Forms.Button buttonupdate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbp;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.ComboBox cbid;
        private System.Windows.Forms.ComboBox cbdel;
    }
}