﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Project_Test
{
    class Item_Class
    {
        
        public DataTable Add_Category(string type)
        {
            try
            {
                SqlConnect.Save("insert into Item_Category (Name) values ('" + type + "')");
                DataTable dt = SqlConnect.fetch("Select *from Item_Category");
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
        public DataTable delete(string t)
        {
            try
            {
                SqlConnect.Save("Delete from Item where Item_Name='"+t+"'");
                MessageBox.Show("Deleted Successfully");
                DataTable dt = SqlConnect.fetch("Select *from Item");
                return dt;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
        public void update_Item(string id,string col,string data,string loc)
        {
            try
            {
                if (col == "Item Name")
                {
                    SqlConnect.Save("Update Item set Item_name='" + data + "' where Item_Name='" + id + "'");
                }
                else if (col == "Item_description")
                {
                    SqlConnect.Save("Update Item set Item_Description='" + data + "' where Item_IName='" + id + "'");
                }
                else if (col == "Quantity")
                {
                    SqlConnect.Save("Update Item set Quantity_in_Stock='" + int.Parse(data) + "' where Item_Name='" + id + "'");
                }
                else if (col == "Rate")
                {
                    SqlConnect.Save("Update Item set Rate='" + int.Parse(data) + "' where Item_Name='" + id + "'");
                }
                else if (col == "Image")
                {
                    SqlConnect.Save("Update Item set Image='" + loc + "' where Item_Name='" + id + "'");
                }
                MessageBox.Show("Data Updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public DataTable Item_Add(string n,int r,string ca,int q,string des,string loc)
        {
            try
            {

                SqlConnect.Save("Insert into Item (Item_Name,Item_Description,Quantity_in_Stock,Rate,Item_Category,Image) values ('" + n + "','" + des + "','" + q + "','" + r + "','" + ca + "','" + loc + "')");
                DataTable dt = SqlConnect.fetch("Select * from Item");
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
        public DataTable up_category(int n,string data)
        {
            try
            {
                SqlConnect.Save("Update Item_Category set Name='"+data+"' where ID='"+n+"'");
                DataTable d = SqlConnect.fetch("Select *from Item_Category");
                return d;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
        public DataTable del_ca(int cat_id)
        {
            try
            {
                SqlConnect.Save("Delete from Item_Category where ID='" + cat_id + "'");
                DataTable dt = SqlConnect.fetch("Select * from Item_Category");
                return dt;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
    }
}
