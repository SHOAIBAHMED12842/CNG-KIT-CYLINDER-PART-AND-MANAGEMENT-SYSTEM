﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Project_Test
{
    class Vendor_Order_Class
    {
        SqlConnection s = new SqlConnection(SqlConnect.cs);
        SqlCommand cmd;
        public void Add(string name, string city, string province, string phone, string bal)
        {
            int p = Convert.ToInt32(phone);
            int c = Convert.ToInt32(bal);
            s.Open();
            cmd = new SqlCommand("Insert into Vendor() values('" + name + "','" + city + "','" + province + "','" + phone + "','"+bal+"')", s);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data has been stored.");
            s.Close();
        }
        public DataTable show()
        {
            s.Open();
            SqlDataAdapter c = new SqlDataAdapter("Select *from Vendor", s);
            DataTable dt = new DataTable();
            c.Fill(dt);
            return dt;

        }

    }
         
}
