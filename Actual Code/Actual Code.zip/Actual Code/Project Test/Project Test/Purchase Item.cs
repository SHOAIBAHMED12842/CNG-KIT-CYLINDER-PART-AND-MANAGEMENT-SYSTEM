﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_Test
{
    public partial class Purchase_Item : Form
    {
        List<Panel> l_panel = new List<Panel>();
        int index;
        public Purchase_Item()
        {
            InitializeComponent();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
        public void dtable()
        {
            dgvinvoice.ColumnCount = 3;
            dgvinvoice.Columns[0].HeaderText = "";
            dgvinvoice.Columns[1].HeaderText = "";
            dgvinvoice.Columns[2].HeaderText = "";
            DataGridViewComboBoxColumn com = new DataGridViewComboBoxColumn();
            com.HeaderText = "";
            DataTable dt = SqlConnect.fetch("select item_name from tblname");
            com.Items.AddRange(dt);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                com.Items.Add(dt.Rows[i][0].ToString());
            }
            dgvinvoice.Columns.Add(com);

        }
        public void dgvshow()
        {

            // dgvitem.Columns[0].HeaderText = "ID";
            DataGridViewComboBoxColumn com = new DataGridViewComboBoxColumn();
            DataTable dt = SqlConnect.fetch("select item_name from item ");

            com.HeaderText = "Items";
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                com.Items.Add(dt.Rows[i][0].ToString());
            }
            dgvitem.Columns.Add(com);
            DataGridViewComboBoxColumn com1 = new DataGridViewComboBoxColumn();

            DataTable dt1 = SqlConnect.fetch("select name from services ");
            com1.HeaderText = "Service";
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                com1.Items.Add(dt1.Rows[i][0].ToString());
            }
            dgvitem.Columns.Add(com1);

            dgvitem.ColumnCount = 9;
            dgvitem.Columns[3].HeaderText = "S.Charge";

            // dgvitem.ColumnCount = 9;


            dgvitem.Columns[4].HeaderText = "Quantity of item";
            dgvitem.Columns[5].HeaderText = "Rate";
            dgvitem.Columns[6].HeaderText = "Amount";
            dgvitem.Columns[7].HeaderText = "Date";
            dgvitem.Columns[8].HeaderText = "Status";






        }
        private void Purchase_Item_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cNG_Kits_Cylinders_PartsDataSetCustomer.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.cNG_Kits_Cylinders_PartsDataSetCustomer.Customer);
            // TODO: This line of code loads data into the 'cNG_Kits_Cylinders_PartsDataSet.Item' table. You can move, or remove it, as needed.
            this.itemTableAdapter.Fill(this.cNG_Kits_Cylinders_PartsDataSet.Item);
            l_panel.Add(panelpurchaseitem);
            l_panel.Add(panelInvoiceBill);
            l_panel.Add(panelInvoicePayment);
            l_panel[index].BringToFront();
            dgvshow();
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel4_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

            Customer c = new Customer();
            c.Show();
            this.Hide();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
            this.Hide();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            if (index < l_panel.Count - 1)
            {
                l_panel[++index].BringToFront();
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            if (index > 0)
                l_panel[--index].BringToFront();
        }

        private void buttonCustomer_Click(object sender, EventArgs e)
        {

            Customer c = new Customer();
            c.Show();
            this.Hide();
        }

        private void buttonitemclear_Click(object sender, EventArgs e)
        {
            textBoxc_price.Text = "";
            textBoxq_available.Text = "";
            textBoxq_req.Text = "";
            textBoxt_am.Text = "";
            MessageBox.Show("All Feilds Clear");
        }

        private void panelInvoicePayment_Paint(object sender, PaintEventArgs e)
        {

        }
        private void SERVICE(object sender, DataGridViewCellEventArgs e)
        {
            int amount = 0;
            try
            {
                amount = int.Parse(dgvitem.Rows[e.RowIndex].Cells[4].Value.ToString()) * int.Parse(dgvitem.Rows[e.RowIndex].Cells[5].Value.ToString());
                amount = amount + int.Parse(dgvitem.Rows[e.RowIndex].Cells[3].Value.ToString());
                dgvitem.Rows[e.RowIndex].Cells[6].Value = amount;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < dgvitem.RowCount - 1; i++)
                {
                    SqlConnect.Save("insert into purchased_item_detail values('" + cbcid.Text + "','" + dgvitem.Rows[i].Cells[1].Value + "','" + dgvitem.Rows[i].Cells[3].Value + "','" + dgvitem.Rows[i].Cells[2].Value + "','" + dgvitem.Rows[i].Cells[4].Value + "','" + dgvitem.Rows[i].Cells[5].Value + "','" + dgvitem.Rows[i].Cells[6].Value + "','" + dgvitem.Rows[i].Cells[7].Value + "','" + dgvitem.Rows[i].Cells[8].Value + "','" + dgvitem.Rows[i].Cells[0].Value + "') ");
                }
                dgvitem.DataSource = null;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void dgvitem_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //DataTable dt2 = SqlConnect.fetch("Select customer_id from Customer where Customer_ID='"++"'");
                DataTable dt = SqlConnect.fetch("select Amount from Services where Name='" + dgvitem.Rows[e.RowIndex].Cells[2].Value.ToString() + "'");
                DataTable dt1 = SqlConnect.fetch("Select rate from item where item_name='" + dgvitem.Rows[e.RowIndex].Cells[1].Value.ToString() + "'");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_MouseHover(object sender, EventArgs e)
        {
            cbitem.Items.Clear();
            DataTable dt = SqlConnect.fetch("select Customer_ID from Customer");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                cbitem.Items.Add(dt.Rows[i][0].ToString());
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cbcid_MouseHover(object sender, EventArgs e)
        {
            cbcid.Items.Clear();
            DataTable dt = SqlConnect.fetch("select Customer_ID from Customer");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                cbcid.Items.Add(dt.Rows[i][0].ToString());
            }
        }
        private void cbcid_Click(object sender, EventArgs e)
        {
            //SqlConnection con = new SqlConnection("Data Source=DESKTOP-MPKH00B;Initial Catalog=CNG_Kits_Cylinders_Parts;Integrated Security=True");
            //con.Open();
            //string selectQuery = "SELECT * FROM Customer WHERE Customer_ID='" + int.TryParse(cbcid.Text,out int id)+"'";
            //SqlCommand com = new SqlCommand(selectQuery, con);
            //SqlDataReader mdr = com.ExecuteReader();
            //if (mdr.Read())
            //{
            //    tbn.Text = (mdr["Name"].ToString());
            //    textBoxV_name.Text = (mdr["Veihcle_Number"].ToString());
            //    maskedTextBoxm_no.Text = (mdr["Plate_Number"].ToString());
            //    maskedTextBoxcnic.Text = (mdr["CNIC_Number"].ToString());
            //}
            //con.Close();
            //Purchase_item_Class p = new Purchase_item_Class();
            //try
            //{

            //    DataTable dt1 = p.cust_detail(cbcid.Text);
            //    tbn.Text = dt1.Rows[0]["Name"].ToString();
            //    textBoxV_name.Text = dt1.Rows[0]["Veihcle_Name"].ToString();
            //    maskedTextBoxm_no.Text = dt1.Rows[0]["Plate_Number"].ToString();
            //    maskedTextBoxcnic.Text = dt1.Rows[0]["CNIC_Number"].ToString();
            //}
            //catch (Exception ex)
            //{
               
            //}
        }

        private void cbitem_Click(object sender, EventArgs e)
        {
            try
            {
                string c = cbitem.ToString();
                DataTable dt = SqlConnect.fetch("Select Quantity_in_Stock from Item where Item_ID='" + int.TryParse(c, out int id) + "'");
                textBoxq_available.Text = dt.Rows[0][0].ToString();
            }
            catch
            {
                throw;
            }
        }

        private void panelpurchaseitem_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            PI2 p = new PI2();
            p.Show();
            this.Hide();

        }

        private void dgvitem_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvitem.Rows[0].Cells[0].Value = cbcid.Text;

        }

        private void cbcn_MouseHover(object sender, EventArgs e)
        {
            try
            {
                cbcn.Items.Clear();
                DataTable dt = SqlConnect.fetch("select Customer_Name from Customer");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    cbcn.Items.Add(dt.Rows[i][0].ToString());
                }
            }
            catch (Exception ex)
            {
               // MessageBox.Show(ex.Message);
            }
        }

        private void panelInvoicePayment_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void cbcid_SelectedIndexChanged(object sender, EventArgs e)
        {
            Purchase_item_Class p = new Purchase_item_Class();
            try
            {

                DataTable dt1 = p.cust_detail(cbcid.Text);
                tbn.Text = dt1.Rows[0]["Name"].ToString();
                textBoxV_name.Text = dt1.Rows[0]["Veihcle_Name"].ToString();
                maskedTextBoxm_no.Text = dt1.Rows[0]["Plate_Number"].ToString();
                maskedTextBoxcnic.Text = dt1.Rows[0]["CNIC_Number"].ToString();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }
    }
}




