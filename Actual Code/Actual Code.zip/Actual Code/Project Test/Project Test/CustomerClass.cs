﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Diagnostics;

namespace Project_Test
{
    class CustomerClass
    {
        public void Add(string name, string v_name, string plate_no,string phone_no,string CNICNo,string loc)
        {
            try
            {
                SqlConnect.Save("Insert into Customer (Name,Phone_Number,Veihcle_Name,Plate_Number,CNIC_Number,image) values ('" + name + "','" + phone_no + "','" + v_name + "','" + plate_no + "','" + CNICNo + "','"+loc+"')");
                MessageBox.Show("Data Inserted");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void update(int cust_id,string col,string data)
        {
            try
            {
                SqlConnect.fetch("Select *from Customer where Customer_ID='" + cust_id + "'");
                if (col == "Customer Name")
                {
                    SqlConnect.Save("Update Customer set Name='" + data + "' where Customer_ID='" + cust_id + "'");
                }
                else if (col == "Phone Number")
                {
                    SqlConnect.Save("Update Customer set Phone_Number='" + data + "' where Customer_ID='" + cust_id + "'");
                }
                else if (col == "CNIC Number")
                {
                    SqlConnect.Save("Update Customer set CNIC_Number='" + data + "' where Customer_ID='" + cust_id + "'");
                }
                else if (col == "Vehicle Name")
                {
                    SqlConnect.Save("Update Customer set Vehicle_Name='" + data + "' where Customer_ID='" + cust_id + "'");
                }
                else if (col == "Plate Number")
                {
                    SqlConnect.Save("Update Customer set Plate_Number='" + data + "' where Customer_ID='" + cust_id + "'");
                }
                else if (col == "Image")
                {
                    SqlConnect.Save("Update Customer set Image='" + data + "' where Customer_ID='" + cust_id + "'");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Del(int cust_id)
        {
            try
            {
                SqlConnect.Save("Delete from Customer where Customer_ID='" + cust_id + "'");

                MessageBox.Show("Deleted Succesfully.");
            }
                catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public DataTable Show()
        {
            try
            {
                DataTable dt = SqlConnect.fetch("Select * from Customer");
                return dt;
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
    }
}

