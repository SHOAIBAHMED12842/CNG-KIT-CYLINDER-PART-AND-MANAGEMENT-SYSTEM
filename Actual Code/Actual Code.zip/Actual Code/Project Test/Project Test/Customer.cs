﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Project_Test
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
            textBoxpic.Visible = false;
        }

        private void panelcustomer_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {   if (cbid.Text=="")
            {
                MessageBox.Show("This Feild is Compulsory. Enter Customer Id To Search.");
            }
            else
            {
                dataGridViewcustomer.AutoGenerateColumns = false;
                DataTable dt = SqlConnect.fetch("select * from Customer where Customer_ID = '" + int.Parse(cbid.Text) + "'");
                dataGridViewcustomer.DataSource = dt;
                //DataView dv = p.Search(Convert.ToInt16(textBoxSea.Text));
                //dataGridViewcustomer.DataSource = dv.ToTable();
            }
        }

        private void buttonDel_Click(object sender, EventArgs e)
        {
            if (cbdel.Text=="")
            {
                MessageBox.Show("Need to fill the delete box\n to delete the data.");
            }
            else
            {
                CustomerClass p = new CustomerClass();
                p.Del(int.Parse(cbdel.Text));
            }
        }
        private void buttonImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog o = new OpenFileDialog();
            if (o.ShowDialog() == DialogResult.OK)
            {
                textBoxpic.Text = o.FileName;
                pictureBox2.Image = new Bitmap(o.FileName);
                pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            }
           
        }
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
           
        }
        private void buttonslist_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridViewcustomer.AutoGenerateColumns = false;
                DataTable dt = SqlConnect.fetch("select * from Customer");
                dataGridViewcustomer.DataSource = dt;
                MessageBox.Show("Data Displayed");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Customer_Load(object sender, EventArgs e)
        {
        }
        private void buttonPIT_Click(object sender, EventArgs e)
        {
            Purchase_Item p = new Purchase_Item();
            p.Show();
            this.Hide();
        }
        private void buttonSO_Click(object sender, EventArgs e)
        {
            Sales s = new Sales();
            s.Show();
            this.Hide();
        }
        private void buttonE_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
            this.Hide();
        }
        
        private void comboBox2_MouseHover(object sender, EventArgs e)
        {
            try
            {
                cbid.Items.Clear();
                DataTable dt = SqlConnect.fetch("select Customer_ID from Customer");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    cbid.Items.Add(dt.Rows[i][0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            CustomerClass c = new CustomerClass();
            if(textBoxpic.Text!="")
                tbp.Text = textBoxpic.Text;
            c.update(int.Parse(cbid.Text),cbupdate.Text,tbp.Text);
        }

        private void bs_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text == "" || textBoxVName.Text == "" || maskedTextBoxPhone.Text == "" || maskedTextBoxPname.Text == "" || maskedTextBoxCNIC.Text == "")
            {
                MessageBox.Show("Al Feilds are necessary.");
            }
            else
            {
                string loc = "";
                try
                {
                    loc = Path.Combine(Application.StartupPath + @"\Images", Path.GetFileName(textBoxpic.Text));
                    File.Copy(Path.Combine(textBoxpic.Text), loc, true);
                }
                catch (Exception)
                {
                    loc = "";

                }
                CustomerClass p = new CustomerClass();
                p.Add(textBoxName.Text, textBoxVName.Text, maskedTextBoxPname.Text, maskedTextBoxPhone.Text, maskedTextBoxCNIC.Text, loc);
                textBoxName.Clear();
                maskedTextBoxPname.Clear();
                maskedTextBoxCNIC.Clear();
                maskedTextBoxPhone.Clear();
                textBoxName.Clear();
                textBoxVName.Clear();
                DataTable d=p.Show();
                dataGridViewcustomer.DataSource = d;
            }

        }

        private void cbdel_MouseHover(object sender, EventArgs e)
        {
            try
            {
                cbdel.Items.Clear();
                DataTable dt = SqlConnect.fetch("select Customer_ID from Customer");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    cbdel.Items.Add(dt.Rows[i][0].ToString());
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}