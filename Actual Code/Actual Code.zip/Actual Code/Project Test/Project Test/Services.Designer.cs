﻿namespace Project_Test
{
    partial class Services
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Services));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonup = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridViewShow = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonadD = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.maskedTextBoxserv = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxchar = new System.Windows.Forms.MaskedTextBox();
            this.buttonDEL = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxuprice = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxDEL = new System.Windows.Forms.ComboBox();
            this.servicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cNG_Kits_Cylinders_PartsDataSet9 = new Project_Test.CNG_Kits_Cylinders_PartsDataSet9();
            this.servicesTableAdapter = new Project_Test.CNG_Kits_Cylinders_PartsDataSet9TableAdapters.ServicesTableAdapter();
            this.comboBoxfeild = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxdata = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet9)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(123, 440);
            this.panel1.TabIndex = 272;
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button1.Location = new System.Drawing.Point(-1, 317);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 56);
            this.button1.TabIndex = 5;
            this.button1.Text = "EXIT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.GreenYellow;
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(123, 100);
            this.panel5.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 100);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(129, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(559, 100);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Yellow;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(123, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(772, 44);
            this.panel3.TabIndex = 273;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("American Classic Extra Bold", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(284, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "SERVIES REGISTRATION";
            // 
            // buttonup
            // 
            this.buttonup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonup.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonup.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonup.Location = new System.Drawing.Point(177, 336);
            this.buttonup.Name = "buttonup";
            this.buttonup.Size = new System.Drawing.Size(95, 23);
            this.buttonup.TabIndex = 284;
            this.buttonup.Text = "UPDATE";
            this.buttonup.UseVisualStyleBackColor = true;
            this.buttonup.Click += new System.EventHandler(this.buttonup_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(154, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 16);
            this.label2.TabIndex = 282;
            this.label2.Text = "CHARGES:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(382, 231);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 16);
            this.label7.TabIndex = 281;
            this.label7.Text = "DELETE:";
            // 
            // dataGridViewShow
            // 
            this.dataGridViewShow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShow.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dataGridViewShow.Location = new System.Drawing.Point(561, 100);
            this.dataGridViewShow.Name = "dataGridViewShow";
            this.dataGridViewShow.Size = new System.Drawing.Size(312, 244);
            this.dataGridViewShow.TabIndex = 279;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Service_ID";
            this.Column1.HeaderText = "SERVICE ID";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Name";
            this.Column2.HeaderText = "NAME";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Amount";
            this.Column3.HeaderText = "CHARGES";
            this.Column3.Name = "Column3";
            this.Column3.Width = 70;
            // 
            // buttonadD
            // 
            this.buttonadD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonadD.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonadD.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonadD.Location = new System.Drawing.Point(420, 168);
            this.buttonadD.Name = "buttonadD";
            this.buttonadD.Size = new System.Drawing.Size(75, 23);
            this.buttonadD.TabIndex = 276;
            this.buttonadD.Text = "ADD";
            this.buttonadD.UseVisualStyleBackColor = true;
            this.buttonadD.Click += new System.EventHandler(this.buttonadD_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(154, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 16);
            this.label1.TabIndex = 274;
            this.label1.Text = "SERVICE NAME:";
            // 
            // maskedTextBoxserv
            // 
            this.maskedTextBoxserv.Location = new System.Drawing.Point(353, 98);
            this.maskedTextBoxserv.Mask = "AAAAAAAAAAAAAAA";
            this.maskedTextBoxserv.Name = "maskedTextBoxserv";
            this.maskedTextBoxserv.Size = new System.Drawing.Size(142, 20);
            this.maskedTextBoxserv.TabIndex = 287;
            // 
            // maskedTextBoxchar
            // 
            this.maskedTextBoxchar.Location = new System.Drawing.Point(353, 128);
            this.maskedTextBoxchar.Mask = "00000";
            this.maskedTextBoxchar.Name = "maskedTextBoxchar";
            this.maskedTextBoxchar.Size = new System.Drawing.Size(142, 20);
            this.maskedTextBoxchar.TabIndex = 1;
            this.maskedTextBoxchar.ValidatingType = typeof(int);
            // 
            // buttonDEL
            // 
            this.buttonDEL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDEL.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDEL.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonDEL.Location = new System.Drawing.Point(385, 290);
            this.buttonDEL.Name = "buttonDEL";
            this.buttonDEL.Size = new System.Drawing.Size(95, 23);
            this.buttonDEL.TabIndex = 288;
            this.buttonDEL.Text = "DELETE";
            this.buttonDEL.UseVisualStyleBackColor = true;
            this.buttonDEL.Click += new System.EventHandler(this.buttonDEL_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(174, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 16);
            this.label3.TabIndex = 290;
            this.label3.Text = "UPDATE PRICE:";
            // 
            // comboBoxuprice
            // 
            this.comboBoxuprice.FormattingEnabled = true;
            this.comboBoxuprice.Location = new System.Drawing.Point(177, 193);
            this.comboBoxuprice.Name = "comboBoxuprice";
            this.comboBoxuprice.Size = new System.Drawing.Size(144, 21);
            this.comboBoxuprice.TabIndex = 291;
            this.comboBoxuprice.MouseHover += new System.EventHandler(this.comboBoxuprice_MouseHover);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(174, 290);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 16);
            this.label4.TabIndex = 293;
            this.label4.Text = "ENTER DATA:";
            // 
            // comboBoxDEL
            // 
            this.comboBoxDEL.DataSource = this.servicesBindingSource;
            this.comboBoxDEL.DisplayMember = "Service_ID";
            this.comboBoxDEL.FormattingEnabled = true;
            this.comboBoxDEL.Location = new System.Drawing.Point(385, 254);
            this.comboBoxDEL.Name = "comboBoxDEL";
            this.comboBoxDEL.Size = new System.Drawing.Size(144, 21);
            this.comboBoxDEL.TabIndex = 294;
            this.comboBoxDEL.MouseHover += new System.EventHandler(this.comboBoxDEL_MouseHover);
            // 
            // servicesBindingSource
            // 
            this.servicesBindingSource.DataMember = "Services";
            this.servicesBindingSource.DataSource = this.cNG_Kits_Cylinders_PartsDataSet9;
            // 
            // cNG_Kits_Cylinders_PartsDataSet9
            // 
            this.cNG_Kits_Cylinders_PartsDataSet9.DataSetName = "CNG_Kits_Cylinders_PartsDataSet9";
            this.cNG_Kits_Cylinders_PartsDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // servicesTableAdapter
            // 
            this.servicesTableAdapter.ClearBeforeFill = true;
            // 
            // comboBoxfeild
            // 
            this.comboBoxfeild.FormattingEnabled = true;
            this.comboBoxfeild.Items.AddRange(new object[] {
            "Name",
            "Charges"});
            this.comboBoxfeild.Location = new System.Drawing.Point(177, 254);
            this.comboBoxfeild.Name = "comboBoxfeild";
            this.comboBoxfeild.Size = new System.Drawing.Size(144, 21);
            this.comboBoxfeild.TabIndex = 296;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("American Classic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Location = new System.Drawing.Point(174, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 16);
            this.label6.TabIndex = 295;
            this.label6.Text = "SELECT COLUMN:";
            // 
            // textBoxdata
            // 
            this.textBoxdata.Location = new System.Drawing.Point(177, 309);
            this.textBoxdata.Name = "textBoxdata";
            this.textBoxdata.Size = new System.Drawing.Size(144, 20);
            this.textBoxdata.TabIndex = 297;
            // 
            // Services
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.ClientSize = new System.Drawing.Size(895, 440);
            this.Controls.Add(this.textBoxdata);
            this.Controls.Add(this.comboBoxfeild);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBoxDEL);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBoxuprice);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonDEL);
            this.Controls.Add(this.maskedTextBoxchar);
            this.Controls.Add(this.maskedTextBoxserv);
            this.Controls.Add(this.buttonup);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dataGridViewShow);
            this.Controls.Add(this.buttonadD);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Services";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Services";
            this.Load += new System.EventHandler(this.Services_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonup;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridViewShow;
        private System.Windows.Forms.Button buttonadD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxserv;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxchar;
        private System.Windows.Forms.Button buttonDEL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.ComboBox comboBoxuprice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxDEL;
        private CNG_Kits_Cylinders_PartsDataSet9 cNG_Kits_Cylinders_PartsDataSet9;
        private System.Windows.Forms.BindingSource servicesBindingSource;
        private CNG_Kits_Cylinders_PartsDataSet9TableAdapters.ServicesTableAdapter servicesTableAdapter;
        private System.Windows.Forms.ComboBox comboBoxfeild;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxdata;
    }
}