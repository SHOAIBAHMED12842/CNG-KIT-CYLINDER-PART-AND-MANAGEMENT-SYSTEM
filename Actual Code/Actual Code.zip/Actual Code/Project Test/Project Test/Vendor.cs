﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test
{
    public partial class Vendor : Form
    {
        List<Panel> l_panel = new List<Panel>();
        int index;
        public Vendor()
        {
            InitializeComponent();
        }
        Vendor_Order_Class voc = new Vendor_Order_Class();
        Vendor_Registration vr = new Vendor_Registration();
        Purchase_Bill pb = new Purchase_Bill();
        Purchase_Order_Payment pop = new Purchase_Order_Payment();
        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void Vendor_Load(object sender, EventArgs e)
        {
            l_panel.Add(panelVendor);
            l_panel.Add(panelpurchasebill);
            l_panel.Add(panelpurchaseorder);
            l_panel[index].BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
            this.Hide();
        }

        private void button21_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click_1(object sender, EventArgs e)
        {

        }

        private void button27_Click(object sender, EventArgs e)
        {
            panelVendor.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

       
        

        private void buttonNext_Click(object sender, EventArgs e)
        {
            if (index < l_panel.Count - 1)
                l_panel[++index].BringToFront();
        }

        private void buttonBacK_Click(object sender, EventArgs e)
        {
            if (index > 0)
                l_panel[--index].BringToFront();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            voc.Add(textBoxven.Text, textBoxcity.Text, textBoxprovince.Text, textBoxbal.Text, maskedTextBoxphone.Text);
            DataTable dt = voc.show();
            dataGridViewVen.DataSource = dt;
        }

        private void buttonven_reg_Click(object sender, EventArgs e)
        {
            panelRegistration.Show();
            panelRegistration.BringToFront();
        }

        private void buttonBlack_Click(object sender, EventArgs e)
        {
            panelVendor.Show();
            panelVendor.BringToFront();
        }

        private void buttonNew_item_Click(object sender, EventArgs e)
        {
            Item i = new Item();
            i.Show();
            this.Hide();
        }

        private void buttonUp_item_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonCleartext_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            panelRegistration.Show();
            panelRegistration.BringToFront();
        }
    }
}
