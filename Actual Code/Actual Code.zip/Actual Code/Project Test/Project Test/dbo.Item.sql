﻿CREATE TABLE [dbo].[Item] (
    [Item_ID]           INT            IDENTITY (1, 1) NOT NULL,
    [Item_Name]         VARCHAR (15)   NOT NULL,
    [Item_Description]  NVARCHAR (MAX) NOT NULL,
    [Quantity_in_Stock] INT            NOT NULL,
    [Rate]              INT            NOT NULL,
    [Item_Category]     NVARCHAR (50)  NOT NULL,
    [Saled_ID]          INT            NOT NULL,
    [Sales_Payment_ID]  INT            NOT NULL,
    [Vandered_ID]       INT            NOT NULL,
    [Image]             NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_Item] PRIMARY KEY CLUSTERED ([Item_ID] ASC),
    CONSTRAINT [FK_Item_Sales_Order Detail] FOREIGN KEY ([Saled_ID]) REFERENCES [dbo].[Sales_Order Detail] ([Saled_ID]),
    CONSTRAINT [FK_Item_Sales_Invoice_Payment] FOREIGN KEY ([Sales_Payment_ID]) REFERENCES [dbo].[Sales_Invoice_Payment] ([Sales_Payment_ID]),
    CONSTRAINT [FK_Item_Vender_Order_Detail] FOREIGN KEY ([Vandered_ID]) REFERENCES [dbo].[Vender_Order_Detail] ([Vandered_ID])
);

