﻿CREATE TABLE [dbo].[Sales_Order Detail] (
    [Saled_ID]      INT          IDENTITY (1, 1) NOT NULL,
    [Customer_Name] VARCHAR (50) NOT NULL,
    [Item]          VARCHAR (50) NOT NULL,
    [Rate]          INT          NOT NULL,
    [Quantity]      INT          NOT NULL,
    [Total_Amount]  INT          NOT NULL,
    [Date]          DATE         NOT NULL,
    [Status]        VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Sales_Order Detail] PRIMARY KEY CLUSTERED ([Saled_ID] ASC)
);

