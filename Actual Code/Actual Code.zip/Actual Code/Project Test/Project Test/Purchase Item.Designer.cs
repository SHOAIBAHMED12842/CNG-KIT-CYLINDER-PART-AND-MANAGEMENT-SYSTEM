﻿namespace Project_Test
{
    partial class Purchase_Item
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Purchase_Item));
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.buttonPurchaseInfo = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panelpurchaseitem = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.tbn = new System.Windows.Forms.TextBox();
            this.cbcid = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbitem = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.bs = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.panelpoint = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxsear = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.dgvitem = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonitemclear = new System.Windows.Forms.Button();
            this.textBoxt_am = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxq_req = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxc_price = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxq_available = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonCustomer = new System.Windows.Forms.Button();
            this.maskedTextBoxcnic = new System.Windows.Forms.MaskedTextBox();
            this.textBoxV_name = new System.Windows.Forms.TextBox();
            this.maskedTextBoxm_no = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cNG_Kits_Cylinders_PartsDataSetCustomer = new Project_Test.CNG_Kits_Cylinders_PartsDataSetCustomer();
            this.itemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cNG_Kits_Cylinders_PartsDataSet = new Project_Test.CNG_Kits_Cylinders_PartsDataSet();
            this.panelInvoiceBill = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.dgvinvoice = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label22 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button14 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cbcn = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.itemTableAdapter = new Project_Test.CNG_Kits_Cylinders_PartsDataSetTableAdapters.ItemTableAdapter();
            this.customerTableAdapter = new Project_Test.CNG_Kits_Cylinders_PartsDataSetCustomerTableAdapters.CustomerTableAdapter();
            this.panelInvoicePayment = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.buttonclear = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.buttondel_pay = new System.Windows.Forms.Button();
            this.buttonup_pay = new System.Windows.Forms.Button();
            this.buttonaddpay = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panelpurchaseitem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvitem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSetCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet)).BeginInit();
            this.panelInvoiceBill.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvinvoice)).BeginInit();
            this.panelInvoicePayment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.buttonBack);
            this.panel1.Controls.Add(this.buttonNext);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.buttonPurchaseInfo);
            this.panel1.Controls.Add(this.buttonExit);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(123, 590);
            this.panel1.TabIndex = 1;
            // 
            // buttonBack
            // 
            this.buttonBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonBack.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBack.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBack.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonBack.Location = new System.Drawing.Point(-1, 417);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(124, 56);
            this.buttonBack.TabIndex = 7;
            this.buttonBack.Text = "BACK";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonNext.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNext.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNext.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonNext.Location = new System.Drawing.Point(-1, 344);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(123, 56);
            this.buttonNext.TabIndex = 6;
            this.buttonNext.Text = "NEXT";
            this.buttonNext.UseVisualStyleBackColor = false;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button9.Location = new System.Drawing.Point(-1, 255);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(123, 56);
            this.button9.TabIndex = 5;
            this.button9.Text = "Invoice Payment";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button8.Location = new System.Drawing.Point(-1, 183);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(123, 56);
            this.button8.TabIndex = 4;
            this.button8.Text = "Invoice Bill";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // buttonPurchaseInfo
            // 
            this.buttonPurchaseInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPurchaseInfo.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonPurchaseInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPurchaseInfo.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPurchaseInfo.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonPurchaseInfo.Location = new System.Drawing.Point(-1, 113);
            this.buttonPurchaseInfo.Name = "buttonPurchaseInfo";
            this.buttonPurchaseInfo.Size = new System.Drawing.Size(123, 56);
            this.buttonPurchaseInfo.TabIndex = 3;
            this.buttonPurchaseInfo.Text = "Purchase Item Info";
            this.buttonPurchaseInfo.UseVisualStyleBackColor = false;
            // 
            // buttonExit
            // 
            this.buttonExit.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonExit.Location = new System.Drawing.Point(-1, 511);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(123, 56);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "EXIT";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.GreenYellow;
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(123, 100);
            this.panel5.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 100);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Yellow;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(123, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1100, 44);
            this.panel3.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("American Classic Extra Bold", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(231, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "Purchase Item Panel";
            // 
            // panelpurchaseitem
            // 
            this.panelpurchaseitem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.panelpurchaseitem.Controls.Add(this.button2);
            this.panelpurchaseitem.Controls.Add(this.listView1);
            this.panelpurchaseitem.Controls.Add(this.tbn);
            this.panelpurchaseitem.Controls.Add(this.cbcid);
            this.panelpurchaseitem.Controls.Add(this.label1);
            this.panelpurchaseitem.Controls.Add(this.cbitem);
            this.panelpurchaseitem.Controls.Add(this.label37);
            this.panelpurchaseitem.Controls.Add(this.bs);
            this.panelpurchaseitem.Controls.Add(this.label36);
            this.panelpurchaseitem.Controls.Add(this.panelpoint);
            this.panelpurchaseitem.Controls.Add(this.label2);
            this.panelpurchaseitem.Controls.Add(this.textBoxsear);
            this.panelpurchaseitem.Controls.Add(this.label3);
            this.panelpurchaseitem.Controls.Add(this.label4);
            this.panelpurchaseitem.Controls.Add(this.radioButton3);
            this.panelpurchaseitem.Controls.Add(this.radioButton4);
            this.panelpurchaseitem.Controls.Add(this.dgvitem);
            this.panelpurchaseitem.Controls.Add(this.buttonitemclear);
            this.panelpurchaseitem.Controls.Add(this.textBoxt_am);
            this.panelpurchaseitem.Controls.Add(this.label7);
            this.panelpurchaseitem.Controls.Add(this.textBoxq_req);
            this.panelpurchaseitem.Controls.Add(this.label8);
            this.panelpurchaseitem.Controls.Add(this.textBoxc_price);
            this.panelpurchaseitem.Controls.Add(this.label9);
            this.panelpurchaseitem.Controls.Add(this.textBoxq_available);
            this.panelpurchaseitem.Controls.Add(this.label10);
            this.panelpurchaseitem.Controls.Add(this.label11);
            this.panelpurchaseitem.Controls.Add(this.label12);
            this.panelpurchaseitem.Controls.Add(this.buttonCustomer);
            this.panelpurchaseitem.Controls.Add(this.maskedTextBoxcnic);
            this.panelpurchaseitem.Controls.Add(this.textBoxV_name);
            this.panelpurchaseitem.Controls.Add(this.maskedTextBoxm_no);
            this.panelpurchaseitem.Controls.Add(this.label13);
            this.panelpurchaseitem.Controls.Add(this.label14);
            this.panelpurchaseitem.Controls.Add(this.label15);
            this.panelpurchaseitem.Controls.Add(this.label16);
            this.panelpurchaseitem.Controls.Add(this.label17);
            this.panelpurchaseitem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelpurchaseitem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panelpurchaseitem.Location = new System.Drawing.Point(123, 44);
            this.panelpurchaseitem.Name = "panelpurchaseitem";
            this.panelpurchaseitem.Size = new System.Drawing.Size(1100, 546);
            this.panelpurchaseitem.TabIndex = 273;
            this.panelpurchaseitem.Paint += new System.Windows.Forms.PaintEventHandler(this.panelpurchaseitem_Paint);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button2.Location = new System.Drawing.Point(981, 511);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 24);
            this.button2.TabIndex = 283;
            this.button2.Text = "Changes";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(432, 83);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(308, 132);
            this.listView1.TabIndex = 282;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // tbn
            // 
            this.tbn.Location = new System.Drawing.Point(160, 91);
            this.tbn.Name = "tbn";
            this.tbn.Size = new System.Drawing.Size(121, 20);
            this.tbn.TabIndex = 280;
            // 
            // cbcid
            // 
            this.cbcid.DisplayMember = "Name";
            this.cbcid.FormattingEnabled = true;
            this.cbcid.Location = new System.Drawing.Point(158, 60);
            this.cbcid.Name = "cbcid";
            this.cbcid.Size = new System.Drawing.Size(121, 21);
            this.cbcid.TabIndex = 279;
            this.cbcid.ValueMember = "Name";
            this.cbcid.SelectedIndexChanged += new System.EventHandler(this.cbcid_SelectedIndexChanged);
            this.cbcid.Click += new System.EventHandler(this.cbcid_Click);
            this.cbcid.MouseHover += new System.EventHandler(this.cbcid_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(23, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 278;
            this.label1.Text = "CUSTOMER ID:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // cbitem
            // 
            this.cbitem.DisplayMember = "Name";
            this.cbitem.FormattingEnabled = true;
            this.cbitem.Location = new System.Drawing.Point(946, 82);
            this.cbitem.Name = "cbitem";
            this.cbitem.Size = new System.Drawing.Size(121, 21);
            this.cbitem.TabIndex = 277;
            this.cbitem.ValueMember = "Name";
            this.cbitem.Click += new System.EventHandler(this.cbitem_Click);
            this.cbitem.MouseHover += new System.EventHandler(this.comboBox1_MouseHover);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label37.Location = new System.Drawing.Point(772, 86);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(90, 13);
            this.label37.TabIndex = 276;
            this.label37.Text = "ITEM NAME:";
            // 
            // bs
            // 
            this.bs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bs.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bs.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.bs.Location = new System.Drawing.Point(981, 481);
            this.bs.Name = "bs";
            this.bs.Size = new System.Drawing.Size(75, 24);
            this.bs.TabIndex = 275;
            this.bs.Text = "SAVE";
            this.bs.UseVisualStyleBackColor = true;
            this.bs.Click += new System.EventHandler(this.button1_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("American Classic", 15.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label36.Location = new System.Drawing.Point(409, 14);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(279, 27);
            this.label36.TabIndex = 274;
            this.label36.Text = "PURCHASE ITEM INFO";
            // 
            // panelpoint
            // 
            this.panelpoint.BackColor = System.Drawing.Color.Yellow;
            this.panelpoint.Location = new System.Drawing.Point(0, 70);
            this.panelpoint.Name = "panelpoint";
            this.panelpoint.Size = new System.Drawing.Size(10, 56);
            this.panelpoint.TabIndex = 273;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(32, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 15);
            this.label2.TabIndex = 185;
            this.label2.Text = "SEARCH:";
            // 
            // textBoxsear
            // 
            this.textBoxsear.Location = new System.Drawing.Point(111, 253);
            this.textBoxsear.Name = "textBoxsear";
            this.textBoxsear.Size = new System.Drawing.Size(175, 20);
            this.textBoxsear.TabIndex = 184;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("American Classic", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(505, 244);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(219, 20);
            this.label3.TabIndex = 183;
            this.label3.Text = "PURCHASE ITEM INFO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(245, 499);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 178;
            this.label4.Text = "STATUS:";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.radioButton3.Location = new System.Drawing.Point(441, 497);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(124, 17);
            this.radioButton3.TabIndex = 177;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "UNAVAILABLE";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.radioButton4.Location = new System.Drawing.Point(321, 497);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(104, 17);
            this.radioButton4.TabIndex = 176;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "AVAILABLE";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // dgvitem
            // 
            this.dgvitem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvitem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dgvitem.Location = new System.Drawing.Point(56, 285);
            this.dgvitem.Name = "dgvitem";
            this.dgvitem.RowHeadersWidth = 25;
            this.dgvitem.Size = new System.Drawing.Size(947, 190);
            this.dgvitem.TabIndex = 174;
            this.dgvitem.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvitem_CellContentClick);
            this.dgvitem.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SERVICE);
            this.dgvitem.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.SERVICE);
            this.dgvitem.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvitem_RowEnter);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ID";
            this.Column1.Name = "Column1";
            // 
            // buttonitemclear
            // 
            this.buttonitemclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonitemclear.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonitemclear.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonitemclear.Location = new System.Drawing.Point(981, 231);
            this.buttonitemclear.Name = "buttonitemclear";
            this.buttonitemclear.Size = new System.Drawing.Size(75, 23);
            this.buttonitemclear.TabIndex = 173;
            this.buttonitemclear.Text = "CLEAR";
            this.buttonitemclear.UseVisualStyleBackColor = true;
            this.buttonitemclear.Click += new System.EventHandler(this.buttonitemclear_Click);
            // 
            // textBoxt_am
            // 
            this.textBoxt_am.Location = new System.Drawing.Point(946, 188);
            this.textBoxt_am.Name = "textBoxt_am";
            this.textBoxt_am.Size = new System.Drawing.Size(121, 20);
            this.textBoxt_am.TabIndex = 172;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(772, 192);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 13);
            this.label7.TabIndex = 171;
            this.label7.Text = "TOTAL AMOUNT:";
            // 
            // textBoxq_req
            // 
            this.textBoxq_req.Location = new System.Drawing.Point(946, 162);
            this.textBoxq_req.Name = "textBoxq_req";
            this.textBoxq_req.Size = new System.Drawing.Size(121, 20);
            this.textBoxq_req.TabIndex = 170;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Location = new System.Drawing.Point(772, 166);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(159, 13);
            this.label8.TabIndex = 169;
            this.label8.Text = "QUANTITY REQUIRED:";
            // 
            // textBoxc_price
            // 
            this.textBoxc_price.Location = new System.Drawing.Point(946, 136);
            this.textBoxc_price.Name = "textBoxc_price";
            this.textBoxc_price.Size = new System.Drawing.Size(121, 20);
            this.textBoxc_price.TabIndex = 168;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Location = new System.Drawing.Point(772, 140);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 13);
            this.label9.TabIndex = 167;
            this.label9.Text = "CURRENT PRICE:";
            // 
            // textBoxq_available
            // 
            this.textBoxq_available.Location = new System.Drawing.Point(946, 110);
            this.textBoxq_available.Name = "textBoxq_available";
            this.textBoxq_available.Size = new System.Drawing.Size(121, 20);
            this.textBoxq_available.TabIndex = 166;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label10.Location = new System.Drawing.Point(772, 114);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(168, 13);
            this.label10.TabIndex = 165;
            this.label10.Text = "QUANTITY AVAILABLE:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("American Classic", 11.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(350, 44);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 19);
            this.label11.TabIndex = 164;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("American Classic", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label12.Location = new System.Drawing.Point(706, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(109, 24);
            this.label12.TabIndex = 162;
            this.label12.Text = "Item Info";
            // 
            // buttonCustomer
            // 
            this.buttonCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCustomer.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCustomer.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonCustomer.Location = new System.Drawing.Point(160, 208);
            this.buttonCustomer.Name = "buttonCustomer";
            this.buttonCustomer.Size = new System.Drawing.Size(121, 27);
            this.buttonCustomer.TabIndex = 157;
            this.buttonCustomer.Text = "New Customer";
            this.buttonCustomer.UseVisualStyleBackColor = true;
            this.buttonCustomer.Click += new System.EventHandler(this.buttonCustomer_Click);
            // 
            // maskedTextBoxcnic
            // 
            this.maskedTextBoxcnic.Location = new System.Drawing.Point(160, 170);
            this.maskedTextBoxcnic.Mask = "00000-0000000-0";
            this.maskedTextBoxcnic.Name = "maskedTextBoxcnic";
            this.maskedTextBoxcnic.Size = new System.Drawing.Size(121, 20);
            this.maskedTextBoxcnic.TabIndex = 159;
            // 
            // textBoxV_name
            // 
            this.textBoxV_name.Location = new System.Drawing.Point(160, 118);
            this.textBoxV_name.Name = "textBoxV_name";
            this.textBoxV_name.Size = new System.Drawing.Size(121, 20);
            this.textBoxV_name.TabIndex = 160;
            // 
            // maskedTextBoxm_no
            // 
            this.maskedTextBoxm_no.Location = new System.Drawing.Point(160, 144);
            this.maskedTextBoxm_no.Mask = "AAA-000";
            this.maskedTextBoxm_no.Name = "maskedTextBoxm_no";
            this.maskedTextBoxm_no.Size = new System.Drawing.Size(121, 20);
            this.maskedTextBoxm_no.TabIndex = 158;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label13.Location = new System.Drawing.Point(22, 174);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 13);
            this.label13.TabIndex = 130;
            this.label13.Text = "CNIC NO";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label14.Location = new System.Drawing.Point(22, 148);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 13);
            this.label14.TabIndex = 129;
            this.label14.Text = "PLATE NO:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label15.Location = new System.Drawing.Point(22, 122);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(116, 13);
            this.label15.TabIndex = 128;
            this.label15.Text = "VEHICLE NAME:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("American Classic", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label16.Location = new System.Drawing.Point(77, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(141, 20);
            this.label16.TabIndex = 127;
            this.label16.Text = "Customer Info";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label17.Location = new System.Drawing.Point(22, 95);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(133, 13);
            this.label17.TabIndex = 126;
            this.label17.Text = "CUSTOMER NAME:";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.cNG_Kits_Cylinders_PartsDataSetCustomer;
            // 
            // cNG_Kits_Cylinders_PartsDataSetCustomer
            // 
            this.cNG_Kits_Cylinders_PartsDataSetCustomer.DataSetName = "CNG_Kits_Cylinders_PartsDataSetCustomer";
            this.cNG_Kits_Cylinders_PartsDataSetCustomer.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemBindingSource
            // 
            this.itemBindingSource.DataMember = "Item";
            this.itemBindingSource.DataSource = this.cNG_Kits_Cylinders_PartsDataSet;
            // 
            // cNG_Kits_Cylinders_PartsDataSet
            // 
            this.cNG_Kits_Cylinders_PartsDataSet.DataSetName = "CNG_Kits_Cylinders_PartsDataSet";
            this.cNG_Kits_Cylinders_PartsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panelInvoiceBill
            // 
            this.panelInvoiceBill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.panelInvoiceBill.Controls.Add(this.panel2);
            this.panelInvoiceBill.Controls.Add(this.button16);
            this.panelInvoiceBill.Controls.Add(this.dgvinvoice);
            this.panelInvoiceBill.Controls.Add(this.label22);
            this.panelInvoiceBill.Controls.Add(this.listBox2);
            this.panelInvoiceBill.Controls.Add(this.button14);
            this.panelInvoiceBill.Controls.Add(this.textBox3);
            this.panelInvoiceBill.Controls.Add(this.label23);
            this.panelInvoiceBill.Controls.Add(this.label24);
            this.panelInvoiceBill.Controls.Add(this.cbcn);
            this.panelInvoiceBill.Controls.Add(this.label18);
            this.panelInvoiceBill.Controls.Add(this.dateTimePicker2);
            this.panelInvoiceBill.Controls.Add(this.checkBox2);
            this.panelInvoiceBill.Controls.Add(this.checkBox1);
            this.panelInvoiceBill.Controls.Add(this.maskedTextBox1);
            this.panelInvoiceBill.Controls.Add(this.button5);
            this.panelInvoiceBill.Controls.Add(this.label19);
            this.panelInvoiceBill.Controls.Add(this.label20);
            this.panelInvoiceBill.Controls.Add(this.label21);
            this.panelInvoiceBill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInvoiceBill.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelInvoiceBill.Location = new System.Drawing.Point(123, 44);
            this.panelInvoiceBill.Name = "panelInvoiceBill";
            this.panelInvoiceBill.Size = new System.Drawing.Size(1100, 546);
            this.panelInvoiceBill.TabIndex = 278;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Yellow;
            this.panel2.Location = new System.Drawing.Point(0, 139);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 56);
            this.panel2.TabIndex = 274;
            // 
            // button16
            // 
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button16.Location = new System.Drawing.Point(567, 148);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(121, 42);
            this.button16.TabIndex = 190;
            this.button16.Text = "SHOW INVOICE BILL";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // dgvinvoice
            // 
            this.dgvinvoice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvinvoice.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dgvinvoice.Location = new System.Drawing.Point(23, 301);
            this.dgvinvoice.Name = "dgvinvoice";
            this.dgvinvoice.RowHeadersWidth = 25;
            this.dgvinvoice.Size = new System.Drawing.Size(629, 190);
            this.dgvinvoice.TabIndex = 189;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.HeaderText = "S.N0";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "C_NAME";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.HeaderText = "ITEM DESCRIPTION";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.HeaderText = "QUANTITY";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 85;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn5.HeaderText = "ITEM PRICE";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 60;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn6.HeaderText = "TOTAL AMOUNT";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 70;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label22.Location = new System.Drawing.Point(732, 52);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(113, 15);
            this.label22.TabIndex = 188;
            this.label22.Text = "INVOICE BILL:";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Items.AddRange(new object[] {
            "",
            ""});
            this.listBox2.Location = new System.Drawing.Point(735, 73);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(309, 277);
            this.listBox2.TabIndex = 187;
            // 
            // button14
            // 
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button14.Location = new System.Drawing.Point(567, 92);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(121, 41);
            this.button14.TabIndex = 186;
            this.button14.Text = "SHOW NET AMOUNT ";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(567, 50);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(121, 21);
            this.textBox3.TabIndex = 185;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label23.Location = new System.Drawing.Point(460, 52);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 13);
            this.label23.TabIndex = 184;
            this.label23.Text = "NET AMOUNT:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("American Classic", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label24.Location = new System.Drawing.Point(375, 10);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(222, 24);
            this.label24.TabIndex = 183;
            this.label24.Text = "INVOICE BILL INFO";
            // 
            // cbcn
            // 
            this.cbcn.FormattingEnabled = true;
            this.cbcn.Location = new System.Drawing.Point(183, 40);
            this.cbcn.Name = "cbcn";
            this.cbcn.Size = new System.Drawing.Size(125, 21);
            this.cbcn.TabIndex = 182;
            this.cbcn.MouseHover += new System.EventHandler(this.cbcn_MouseHover);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label18.Location = new System.Drawing.Point(25, 43);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(135, 13);
            this.label18.TabIndex = 181;
            this.label18.Text = "CUSTOMER_NAME:";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd.MM.yyyy";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(183, 112);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(125, 21);
            this.dateTimePicker2.TabIndex = 180;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox2.Location = new System.Drawing.Point(109, 169);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(109, 17);
            this.checkBox2.TabIndex = 179;
            this.checkBox2.Text = "BY TONGUE";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox1.Location = new System.Drawing.Point(109, 146);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(134, 17);
            this.checkBox1.TabIndex = 178;
            this.checkBox1.Text = "HAND WRITTEN";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(183, 77);
            this.maskedTextBox1.Mask = "INV000000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(125, 21);
            this.maskedTextBox1.TabIndex = 177;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button5.Location = new System.Drawing.Point(32, 205);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 176;
            this.button5.Text = "SEARCH";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label19.Location = new System.Drawing.Point(24, 79);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(128, 13);
            this.label19.TabIndex = 175;
            this.label19.Text = "INVOICE BILL NO:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label20.Location = new System.Drawing.Point(29, 148);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(68, 13);
            this.label20.TabIndex = 173;
            this.label20.Text = "STATUS:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label21.Location = new System.Drawing.Point(24, 118);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(130, 13);
            this.label21.TabIndex = 172;
            this.label21.Text = "PURCHASE DATE:";
            // 
            // itemTableAdapter
            // 
            this.itemTableAdapter.ClearBeforeFill = true;
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // panelInvoicePayment
            // 
            this.panelInvoicePayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(40)))), ((int)(((byte)(47)))));
            this.panelInvoicePayment.Controls.Add(this.comboBox1);
            this.panelInvoicePayment.Controls.Add(this.buttonclear);
            this.panelInvoicePayment.Controls.Add(this.panel4);
            this.panelInvoicePayment.Controls.Add(this.label35);
            this.panelInvoicePayment.Controls.Add(this.textBox15);
            this.panelInvoicePayment.Controls.Add(this.buttondel_pay);
            this.panelInvoicePayment.Controls.Add(this.buttonup_pay);
            this.panelInvoicePayment.Controls.Add(this.buttonaddpay);
            this.panelInvoicePayment.Controls.Add(this.dataGridView3);
            this.panelInvoicePayment.Controls.Add(this.textBox13);
            this.panelInvoicePayment.Controls.Add(this.label32);
            this.panelInvoicePayment.Controls.Add(this.checkBox3);
            this.panelInvoicePayment.Controls.Add(this.checkBox4);
            this.panelInvoicePayment.Controls.Add(this.label33);
            this.panelInvoicePayment.Controls.Add(this.textBox14);
            this.panelInvoicePayment.Controls.Add(this.label34);
            this.panelInvoicePayment.Controls.Add(this.textBox8);
            this.panelInvoicePayment.Controls.Add(this.label25);
            this.panelInvoicePayment.Controls.Add(this.textBox10);
            this.panelInvoicePayment.Controls.Add(this.label26);
            this.panelInvoicePayment.Controls.Add(this.dateTimePicker3);
            this.panelInvoicePayment.Controls.Add(this.label27);
            this.panelInvoicePayment.Controls.Add(this.textBox11);
            this.panelInvoicePayment.Controls.Add(this.textBox12);
            this.panelInvoicePayment.Controls.Add(this.comboBox3);
            this.panelInvoicePayment.Controls.Add(this.label28);
            this.panelInvoicePayment.Controls.Add(this.label29);
            this.panelInvoicePayment.Controls.Add(this.label30);
            this.panelInvoicePayment.Controls.Add(this.label31);
            this.panelInvoicePayment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInvoicePayment.Location = new System.Drawing.Point(123, 44);
            this.panelInvoicePayment.Name = "panelInvoicePayment";
            this.panelInvoicePayment.Size = new System.Drawing.Size(1100, 546);
            this.panelInvoicePayment.TabIndex = 281;
            this.panelInvoicePayment.Paint += new System.Windows.Forms.PaintEventHandler(this.panelInvoicePayment_Paint_1);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(907, 284);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(179, 21);
            this.comboBox1.TabIndex = 271;
            // 
            // buttonclear
            // 
            this.buttonclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonclear.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonclear.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonclear.Location = new System.Drawing.Point(479, 191);
            this.buttonclear.Name = "buttonclear";
            this.buttonclear.Size = new System.Drawing.Size(82, 23);
            this.buttonclear.TabIndex = 270;
            this.buttonclear.Text = "CLEAR";
            this.buttonclear.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Yellow;
            this.panel4.Location = new System.Drawing.Point(0, 212);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 56);
            this.panel4.TabIndex = 269;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label35.Location = new System.Drawing.Point(707, 201);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(160, 13);
            this.label35.TabIndex = 267;
            this.label35.Text = "DELETE PAYMENT_ID:";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(907, 197);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(175, 20);
            this.textBox15.TabIndex = 266;
            // 
            // buttondel_pay
            // 
            this.buttondel_pay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttondel_pay.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttondel_pay.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttondel_pay.Location = new System.Drawing.Point(840, 236);
            this.buttondel_pay.Name = "buttondel_pay";
            this.buttondel_pay.Size = new System.Drawing.Size(100, 23);
            this.buttondel_pay.TabIndex = 265;
            this.buttondel_pay.Text = "DELETE ALL";
            this.buttondel_pay.UseVisualStyleBackColor = true;
            // 
            // buttonup_pay
            // 
            this.buttonup_pay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonup_pay.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonup_pay.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonup_pay.Location = new System.Drawing.Point(851, 406);
            this.buttonup_pay.Name = "buttonup_pay";
            this.buttonup_pay.Size = new System.Drawing.Size(104, 32);
            this.buttonup_pay.TabIndex = 264;
            this.buttonup_pay.Text = "UPDATE";
            this.buttonup_pay.UseVisualStyleBackColor = true;
            // 
            // buttonaddpay
            // 
            this.buttonaddpay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonaddpay.Font = new System.Drawing.Font("American Classic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonaddpay.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonaddpay.Location = new System.Drawing.Point(283, 191);
            this.buttonaddpay.Name = "buttonaddpay";
            this.buttonaddpay.Size = new System.Drawing.Size(132, 23);
            this.buttonaddpay.TabIndex = 263;
            this.buttonaddpay.Text = "ADD PAYMENT";
            this.buttonaddpay.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.dataGridView3.Location = new System.Drawing.Point(56, 225);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(644, 230);
            this.dataGridView3.TabIndex = 262;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "S.NO";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "DATE";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "PAYMENT STATUS";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "AMOUNT RECIEVED";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "TOTAL AMOUNT";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "BALANCE";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(965, 146);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(121, 20);
            this.textBox13.TabIndex = 261;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label32.Location = new System.Drawing.Point(786, 149);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(78, 13);
            this.label32.TabIndex = 260;
            this.label32.Text = "BALANCE:";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox3.Location = new System.Drawing.Point(965, 124);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(67, 17);
            this.checkBox3.TabIndex = 259;
            this.checkBox3.Text = "UNPAID";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox4.Location = new System.Drawing.Point(965, 101);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(51, 17);
            this.checkBox4.TabIndex = 258;
            this.checkBox4.Text = "PAID";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label33.Location = new System.Drawing.Point(786, 102);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(141, 13);
            this.label33.TabIndex = 257;
            this.label33.Text = "PAYMENT STATUS:";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(961, 67);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(121, 20);
            this.textBox14.TabIndex = 256;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label34.Location = new System.Drawing.Point(786, 70);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(169, 13);
            this.label34.TabIndex = 255;
            this.label34.Text = "SALE INVOICE BILL NO:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(549, 141);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(125, 20);
            this.textBox8.TabIndex = 254;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label25.Location = new System.Drawing.Point(424, 143);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(123, 13);
            this.label25.TabIndex = 253;
            this.label25.Text = "TOTAL AMOUNT:";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(186, 139);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(122, 20);
            this.textBox10.TabIndex = 252;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label26.Location = new System.Drawing.Point(35, 145);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(136, 13);
            this.label26.TabIndex = 251;
            this.label26.Text = "AMOUNT RECIEVE:";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CustomFormat = "dd.MM.yyyy";
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker3.Location = new System.Drawing.Point(549, 105);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(125, 20);
            this.dateTimePicker3.TabIndex = 250;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label27.Location = new System.Drawing.Point(424, 106);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(123, 13);
            this.label27.TabIndex = 249;
            this.label27.Text = "PAYMENT DATE:";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(186, 103);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(121, 20);
            this.textBox11.TabIndex = 248;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(549, 73);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(125, 20);
            this.textBox12.TabIndex = 247;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(186, 70);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 246;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label28.Location = new System.Drawing.Point(35, 72);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(135, 13);
            this.label28.TabIndex = 245;
            this.label28.Text = "CUSTOMER_NAME:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("American Classic", 14.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label29.Location = new System.Drawing.Point(473, 10);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(228, 24);
            this.label29.TabIndex = 244;
            this.label29.Text = "INVOICE PAYMENT ";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label30.Location = new System.Drawing.Point(424, 78);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(85, 13);
            this.label30.TabIndex = 243;
            this.label30.Text = "BILL DATE:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("American Classic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label31.Location = new System.Drawing.Point(35, 106);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(103, 13);
            this.label31.TabIndex = 242;
            this.label31.Text = "BILL STATUS:";
            // 
            // Purchase_Item
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1223, 590);
            this.Controls.Add(this.panelpurchaseitem);
            this.Controls.Add(this.panelInvoiceBill);
            this.Controls.Add(this.panelInvoicePayment);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Purchase_Item";
            this.Text = "Task_Page";
            this.Load += new System.EventHandler(this.Purchase_Item_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panelpurchaseitem.ResumeLayout(false);
            this.panelpurchaseitem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvitem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSetCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cNG_Kits_Cylinders_PartsDataSet)).EndInit();
            this.panelInvoiceBill.ResumeLayout(false);
            this.panelInvoiceBill.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvinvoice)).EndInit();
            this.panelInvoicePayment.ResumeLayout(false);
            this.panelInvoicePayment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonPurchaseInfo;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Panel panelpurchaseitem;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panelpoint;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxsear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Button buttonitemclear;
        private System.Windows.Forms.TextBox textBoxt_am;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxq_req;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxc_price;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxq_available;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonCustomer;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxcnic;
        private System.Windows.Forms.TextBox textBoxV_name;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxm_no;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Panel panelInvoiceBill;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.DataGridView dgvinvoice;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cbcn;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private CNG_Kits_Cylinders_PartsDataSet cNG_Kits_Cylinders_PartsDataSet;
        private System.Windows.Forms.BindingSource itemBindingSource;
        private CNG_Kits_Cylinders_PartsDataSetTableAdapters.ItemTableAdapter itemTableAdapter;
        private CNG_Kits_Cylinders_PartsDataSetCustomer cNG_Kits_Cylinders_PartsDataSetCustomer;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private CNG_Kits_Cylinders_PartsDataSetCustomerTableAdapters.CustomerTableAdapter customerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Panel panelInvoicePayment;
        private System.Windows.Forms.Button buttonclear;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Button buttondel_pay;
        private System.Windows.Forms.Button buttonup_pay;
        private System.Windows.Forms.Button buttonaddpay;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.DataGridView dgvitem;
        private System.Windows.Forms.Button bs;
        private System.Windows.Forms.ComboBox cbitem;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox cbcid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbn;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}