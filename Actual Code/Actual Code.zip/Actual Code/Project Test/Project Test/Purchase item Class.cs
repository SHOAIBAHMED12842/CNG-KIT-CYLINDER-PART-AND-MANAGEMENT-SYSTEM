﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Project_Test
{
    class Purchase_item_Class
    {
        public DataTable cust_detail(string cut_id)
        {
            try
            {
                DataTable dt = SqlConnect.fetch("Select * from Customer where Customer_ID ='" + cut_id + "'");
                return dt;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
                return null; 
            }
        }
        
    }



}
