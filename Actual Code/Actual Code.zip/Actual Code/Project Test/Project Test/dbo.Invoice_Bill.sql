﻿CREATE TABLE [dbo].[Invoice_Bill] (
    [Bill_ID]      INT NOT NULL,
    [Bill_Status]  VARCHAR (15)  NOT NULL,
    [Bill_Date]    NVARCHAR (50) NOT NULL,
    [Total_Amount] INT           NOT NULL,
    CONSTRAINT [PK_Invoice_Bill_1] PRIMARY KEY CLUSTERED ([Bill_ID] ASC),
    CONSTRAINT [FK_Invoice_Bill_Purchased_Item] FOREIGN KEY ([Bill_ID]) REFERENCES [dbo].[Purchased_Item] ([Purchase_ID])
);

