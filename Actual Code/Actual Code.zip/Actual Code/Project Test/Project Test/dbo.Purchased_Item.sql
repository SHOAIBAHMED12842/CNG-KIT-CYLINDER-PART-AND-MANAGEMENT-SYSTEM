﻿CREATE TABLE [dbo].[Purchased_Item] (
    [Purchase_ID] INT NOT NULL,
    [Date]        DATE          NOT NULL,
    [Status]      VARCHAR (15)  NOT NULL,
    CONSTRAINT [PK_Purchased_Item] PRIMARY KEY CLUSTERED ([Purchase_ID] ASC)
);
	ALTER TABLE [dbo].[Purchased.Item]
	ALTER column Purchase_ID int
	GO







