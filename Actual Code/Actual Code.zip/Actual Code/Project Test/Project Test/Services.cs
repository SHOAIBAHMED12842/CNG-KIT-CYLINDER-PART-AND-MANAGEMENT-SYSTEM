﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_Test
{
    public partial class Services : Form
    {
        public Services()
        {
            InitializeComponent();
        }

        private void Services_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cNG_Kits_Cylinders_PartsDataSet9.Services' table. You can move, or remove it, as needed.
            this.servicesTableAdapter.Fill(this.cNG_Kits_Cylinders_PartsDataSet9.Services);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.Show();
            this.Hide();
        }

        private void buttonrefresh_Click(object sender, EventArgs e)
        {

        }
        private void buttonadD_Click(object sender, EventArgs e)
        {
            if (maskedTextBoxserv.Text == "" || maskedTextBoxchar.Text == "") 
            {
                MessageBox.Show("All Fields Are Compulsory");
            }
            else
            {
                try
                {

                    Services_Class s = new Services_Class();
                    DataTable d = s.Add(maskedTextBoxserv.Text, int.Parse(maskedTextBoxchar.Text));
                    dataGridViewShow.DataSource = d;
                    maskedTextBoxchar.Clear();
                    maskedTextBoxserv.Clear();

                    MessageBox.Show("Data Saved ");
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        private void buttonDEL_Click(object sender, EventArgs e)
        {


            if (comboBoxDEL.Text == "")
            {
                MessageBox.Show("Need to fill the delete box\n to delete the data.");
            }
            else
            {
                
                int del = int.Parse(comboBoxDEL.Text);
                Services_Class s = new Services_Class();
                DataTable d=s.Del(del);
                dataGridViewShow.DataSource = d;
                MessageBox.Show("Deleted Succesfully.");
            }
        }

        private void buttonup_Click(object sender, EventArgs e)
        {
            if (comboBoxuprice.Text == "")
            {
                MessageBox.Show("Please enter the required data.");
            }
            else
            {
                int up = int.Parse(comboBoxuprice.Text);
                Services_Class s = new Services_Class();
                if (comboBoxfeild.Text == "Name")
                {
                    DataTable d = s.UpdateN(up, textBoxdata.Text);
                    dataGridViewShow.DataSource = d;
                }
                else
                {
                    DataTable d = s.Updatepr(up, int.Parse(textBoxdata.Text));
                    dataGridViewShow.DataSource = d;
                }
                MessageBox.Show("List Updated.");
            }
        }
        private void comboBoxuprice_MouseHover(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = SqlConnect.fetch("Select Service_ID from Services");
                comboBoxuprice.ValueMember = "Service_ID";
                comboBoxuprice.DisplayMember = "Service_ID";
                comboBoxuprice.DataSource = dt;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBoxDEL_MouseHover(object sender, EventArgs e)
        {
            DataTable dt = SqlConnect.fetch("Select Service_ID from Services");
            comboBoxDEL.DataSource = dt;
        }
    }
}
